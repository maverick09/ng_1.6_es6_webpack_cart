# Module Federation Test Project

Minimal working example of dynamic Module Federation with `createInstance()`.

## Project Structure

```
mfe-test/
├── host/          # Host app (port 3000) - uses createInstance
└── remote/        # Remote app (port 3001) - exposes component
```

## Setup Instructions

### 1. Install Dependencies

```bash
# Terminal 1 - Host
cd host
npm install

# Terminal 2 - Remote
cd remote
npm install
```

### 2. Start Applications

**IMPORTANT: Start remote FIRST, then host**

```bash
# Terminal 1 - Start Remote (FIRST)
cd remote
npm run dev

# Wait for remote to start on http://localhost:3001
# Then in Terminal 2 - Start Host
cd host
npm run dev
```

### 3. Test

1. Open http://localhost:3000 in your browser
2. Click "Remote App" link
3. Watch the console for logs:
   - "🔄 Registering remote..."
   - "✅ Remote registered"
   - "🔄 Loading module..."
   - "✅ Module loaded"

## What to Test

### First Load Test:
1. Open http://localhost:3000/remote directly (hard navigation)
2. Check if it loads without errors on FIRST load
3. This tests the race condition

### Refresh Test:
1. After first load, refresh the page
2. See if it works consistently

## Key Files

**Host:**
- `src/main.jsx` - Creates federation instance
- `src/App.jsx` - Registers and loads remote dynamically

**Remote:**
- `vite.config.js` - Exposes `./App`
- `src/App.jsx` - The component being exposed

## Expected Behavior

✅ Should work on BOTH first load and refresh
✅ Console should show clean loading sequence
❌ If you see "createInstance first" error, there's a timing issue

## Troubleshooting

If it fails:
1. Check both apps are running
2. Check http://localhost:3001/remoteEntry.js returns JS
3. Check console for specific errors
4. Verify React versions match (18.3.1 in both)

## Differences from Your Setup

- Simpler routing (no nested routes)
- No extra services/abstractions
- Minimal dependencies
- Clean separation of concerns

If this works but yours doesn't, the issue is in your codebase structure.
