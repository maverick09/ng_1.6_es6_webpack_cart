import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createInstance } from '@module-federation/enhanced/runtime';

// Create federation instance FIRST
export const federationInstance = createInstance({
  name: 'host',
  remotes: [],
  shared: {
    react: {
      version: '18.3.1',
      lib: () => import('react'),
      shareConfig: {
        singleton: true,
        requiredVersion: '^18.0.0',
      },
    },
    'react-dom': {
      version: '18.3.1',
      lib: () => import('react-dom'),
      shareConfig: {
        singleton: true,
        requiredVersion: '^18.0.0',
      },
    },
  },
});

// Then load app
import('./App').then(({ default: App }) => {
  createRoot(document.getElementById('root')).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
});
