import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { federationInstance } from './main';

function App() {
  return (
    <BrowserRouter>
      <div style={{ padding: '20px', fontFamily: 'Arial' }}>
        <h1>MFE Host App</h1>
        <nav style={{ marginBottom: '20px' }}>
          <Link to="/" style={{ marginRight: '10px' }}>Home</Link>
          <Link to="/remote">Remote App</Link>
        </nav>
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/remote" element={<RemoteRoute />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

function Home() {
  return <div><h2>Home Page</h2><p>Click "Remote App" to load the remote module.</p></div>;
}

function RemoteRoute() {
  const [isRegistered, setIsRegistered] = useState(false);
  const [Component, setComponent] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadRemote = async () => {
      try {
        console.log('🔄 Registering remote...');
        
        // Register remote
        await federationInstance.registerRemotes([
          {
            name: 'remote',
            entry: 'http://localhost:3001/remoteEntry.js',
          },
        ]);
        
        console.log('✅ Remote registered');
        setIsRegistered(true);
        
        // Load module
        console.log('🔄 Loading module...');
        const module = await federationInstance.loadRemote('remote/./App');
        
        console.log('✅ Module loaded:', module);
        setComponent(() => module?.default || module);
        
      } catch (err) {
        console.error('❌ Error:', err);
        setError(err.message);
      }
    };

    loadRemote();
  }, []);

  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;
  if (!isRegistered) return <div>Registering remote...</div>;
  if (!Component) return <div>Loading remote component...</div>;

  return <Component />;
}

export default App;
