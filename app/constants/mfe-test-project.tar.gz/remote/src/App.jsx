import { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);

  return (
    <div style={{ 
      padding: '20px', 
      border: '2px solid blue', 
      borderRadius: '8px',
      backgroundColor: '#f0f8ff' 
    }}>
      <h2>🎉 Remote App Component</h2>
      <p>This component is loaded dynamically from the remote app!</p>
      <p>Port: 3001</p>
      
      <div style={{ marginTop: '20px' }}>
        <button 
          onClick={() => setCount(count + 1)}
          style={{ 
            padding: '10px 20px', 
            fontSize: '16px',
            cursor: 'pointer' 
          }}
        >
          Count: {count}
        </button>
      </div>
    </div>
  );
}

export default App;
