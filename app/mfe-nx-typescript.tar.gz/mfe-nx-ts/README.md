# Module Federation with TypeScript, Vite, and Nx

Complete working example of **dynamic Module Federation** using `createInstance()` with a modern tech stack.

## 🎯 Tech Stack

- **React 18.3.1** with TypeScript
- **Vite 5** (build tool)
- **Nx** (monorepo structure)
- **@module-federation/enhanced** (runtime federation for shell)
- **@module-federation/vite** (build-time federation for remote)
- **React Router v6**

## 📁 Project Structure

```
mfe-nx-workspace/
├── apps/
│   ├── shell/          # Host app (port 3000)
│   │   ├── src/
│   │   │   ├── main.tsx       # Creates federation instance
│   │   │   ├── App.tsx        # Router + dynamic loading
│   │   │   └── App.css
│   │   ├── vite.config.ts
│   │   └── package.json
│   │
│   └── remote/         # Remote app (port 3001)
│       ├── src/
│       │   ├── main.tsx
│       │   ├── App.tsx        # Exposed component
│       │   └── App.css
│       ├── vite.config.ts     # Module Federation config
│       └── package.json
│
├── package.json        # Workspace root
└── nx.json
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
# Install workspace dependencies
npm install

# Install shell app dependencies
cd apps/shell
npm install

# Install remote app dependencies
cd ../remote
npm install
```

### 2. Start Applications

**CRITICAL: Start remote FIRST, then shell**

```bash
# Terminal 1 - Start Remote App (FIRST)
cd apps/remote
npm run dev

# Wait for "Local: http://localhost:3001"
```

```bash
# Terminal 2 - Start Shell App (SECOND)
cd apps/shell
npm run dev

# Open http://localhost:3000
```

### 3. Test Dynamic Loading

#### Option A: Navigate via UI
1. Open http://localhost:3000
2. Click "Load Remote App" button
3. Watch the console logs

#### Option B: Direct URL (tests first-load race condition)
1. Open http://localhost:3000/remote directly
2. This simulates page load with remote route active
3. Should work without errors

## 🔍 What to Look For

### ✅ Success Indicators

**Browser Console Should Show:**
```
✅ Federation instance created
✅ App rendered
🔄 Starting remote registration
✅ Remote registered successfully
🔄 Loading remote module: remoteApp/./App
✅ Module loaded successfully
```

**Browser Should Display:**
- Shell header with navigation
- Remote app component with purple gradient
- Counter and dynamic list features working
- No errors in console

### ❌ Common Issues

**If you see "createInstance first" error:**
- Check that remote is running on port 3001
- Verify http://localhost:3001/remoteEntry.js returns JS
- Ensure React versions match (18.3.1)
- Clear browser cache and restart both apps

**If remote doesn't load:**
- Check browser network tab for failed requests
- Verify CORS is enabled
- Check console for specific error messages

## 📝 Key Implementation Details

### Shell App (apps/shell/src/main.tsx)

```typescript
// Creates federation instance BEFORE React
export const federationInstance = createInstance({
  name: 'shell',
  remotes: [],  // Empty - registered dynamically
  shared: {
    react: {
      version: '18.3.1',
      lib: () => import('react'),
      shareConfig: {
        singleton: true,
        eager: true,
        strictVersion: false,
      },
    },
    // ... react-dom config
  },
});
```

### Shell App (apps/shell/src/App.tsx)

```typescript
// Dynamic registration and loading in useEffect
useEffect(() => {
  const loadRemote = async () => {
    // 1. Register remote
    await federationInstance.registerRemotes([{
      name: 'remoteApp',
      entry: 'http://localhost:3001/remoteEntry.js',
    }]);
    
    // 2. Load module
    const module = await federationInstance
      .loadRemote('remoteApp/./App');
    
    // 3. Render component
    setComponent(() => module?.default || module);
  };
  
  loadRemote();
}, []);
```

### Remote App (apps/remote/vite.config.ts)

```typescript
federation({
  name: 'remoteApp',
  filename: 'remoteEntry.js',
  exposes: {
    './App': './src/App.tsx',  // Exposed module
  },
  shared: {
    react: { singleton: true, eager: true },
    'react-dom': { singleton: true, eager: true },
  },
})
```

## 🧪 Testing Scenarios

### Scenario 1: Cold Start
1. Close all browser tabs
2. Clear browser cache
3. Navigate directly to http://localhost:3000/remote
4. **Expected:** Should load without errors

### Scenario 2: Navigation
1. Open http://localhost:3000
2. Click "Remote App" link
3. **Expected:** Smooth transition, no errors

### Scenario 3: Refresh
1. Navigate to /remote
2. Refresh page multiple times
3. **Expected:** Consistent loading every time

### Scenario 4: Standalone Remote
1. Open http://localhost:3001
2. **Expected:** Remote app runs independently

## 🔧 Configuration Details

### Environment Variables (Optional)

You can configure the remote URL via environment variables:

```bash
# .env.local in shell app
VITE_REMOTE_URL=http://localhost:3001/remoteEntry.js
```

Then in main.tsx:
```typescript
entry: import.meta.env.VITE_REMOTE_URL || 'http://localhost:3001/remoteEntry.js'
```

### Build for Production

```bash
# Build both apps
cd apps/remote
npm run build

cd ../shell
npm run build
```

### Preview Production Build

```bash
# Remote
cd apps/remote
npm run preview

# Shell (in new terminal)
cd apps/shell  
npm run preview
```

## 🐛 Troubleshooting

### Remote Entry Not Found
```
Error: Failed to fetch http://localhost:3001/remoteEntry.js
```

**Solution:**
- Ensure remote app is running
- Check firewall/antivirus isn't blocking ports
- Verify CORS is enabled in remote vite.config.ts

### React Version Mismatch
```
Version X.X.X from shell does not satisfy requirement of remoteApp
```

**Solution:**
- Check both package.json files have React 18.3.1
- Delete node_modules and reinstall
- Set `strictVersion: false` in shared config

### Module Not Found
```
Module remoteApp/./App is null or undefined
```

**Solution:**
- Verify the expose path in remote's vite.config.ts
- Check that App.tsx has a default export
- Rebuild the remote app

### TypeScript Errors

If you see TypeScript errors about module types:

```typescript
// Add to shell/src/vite-env.d.ts
declare module 'remoteApp/App' {
  const component: React.ComponentType;
  export default component;
}
```

## 📚 Learning Resources

- [Module Federation Docs](https://module-federation.io/)
- [Vite Plugin Federation](https://github.com/module-federation/vite)
- [Nx Documentation](https://nx.dev)

## 🎓 Key Learnings

1. **Instance Creation Timing**: Federation instance must be created BEFORE any React code runs
2. **Registration Before Loading**: Always register remotes before loading modules
3. **Shared Dependencies**: Use `eager: true` and `strictVersion: false` for better compatibility
4. **Error Handling**: Always wrap federation calls in try-catch
5. **Loading States**: Provide clear loading indicators for better UX

## 📄 License

MIT

---

**Built with ❤️ to demonstrate Module Federation best practices**
