#!/bin/bash

echo "🚀 Module Federation TypeScript Setup"
echo "======================================"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js 18+ first."
    exit 1
fi

echo "✅ Node.js version: $(node -v)"
echo ""

# Install workspace dependencies
echo "📦 Installing workspace dependencies..."
npm install

# Install shell dependencies
echo ""
echo "📦 Installing shell app dependencies..."
cd apps/shell
npm install
cd ../..

# Install remote dependencies
echo ""
echo "📦 Installing remote app dependencies..."
cd apps/remote
npm install
cd ../..

echo ""
echo "✅ Setup complete!"
echo ""
echo "📝 Next steps:"
echo ""
echo "1. Start the remote app (in terminal 1):"
echo "   cd apps/remote && npm run dev"
echo ""
echo "2. Start the shell app (in terminal 2):"
echo "   cd apps/shell && npm run dev"
echo ""
echo "3. Open http://localhost:3000 in your browser"
echo ""
echo "🎉 Happy coding!"
