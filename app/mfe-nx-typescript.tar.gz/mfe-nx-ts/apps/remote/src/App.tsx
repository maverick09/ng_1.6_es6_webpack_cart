import { useState } from 'react';
import './App.css';

interface DataItem {
  id: number;
  name: string;
  timestamp: string;
}

function App() {
  const [count, setCount] = useState<number>(0);
  const [data, setData] = useState<DataItem[]>([]);

  const addDataItem = () => {
    const newItem: DataItem = {
      id: Date.now(),
      name: `Item ${data.length + 1}`,
      timestamp: new Date().toLocaleTimeString(),
    };
    setData([...data, newItem]);
  };

  return (
    <div className="remote-app">
      <div className="remote-header">
        <h2>🚀 Remote Application</h2>
        <p className="remote-badge">Loaded via Module Federation</p>
      </div>

      <div className="remote-content">
        <div className="feature-section">
          <h3>Counter Demo</h3>
          <div className="counter-display">
            <span className="count-value">{count}</span>
          </div>
          <div className="button-group">
            <button 
              onClick={() => setCount(count - 1)}
              className="btn btn-secondary"
            >
              Decrement
            </button>
            <button 
              onClick={() => setCount(0)}
              className="btn btn-neutral"
            >
              Reset
            </button>
            <button 
              onClick={() => setCount(count + 1)}
              className="btn btn-primary"
            >
              Increment
            </button>
          </div>
        </div>

        <div className="feature-section">
          <h3>Dynamic List Demo</h3>
          <button 
            onClick={addDataItem}
            className="btn btn-success"
          >
            Add Item
          </button>
          
          {data.length > 0 ? (
            <ul className="data-list">
              {data.map((item) => (
                <li key={item.id} className="data-item">
                  <strong>{item.name}</strong>
                  <span className="timestamp">{item.timestamp}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="empty-state">No items yet. Click "Add Item" to get started!</p>
          )}
        </div>

        <div className="info-section">
          <h3>📋 Component Info</h3>
          <table className="info-table">
            <tbody>
              <tr>
                <td><strong>App Name:</strong></td>
                <td>Remote Application</td>
              </tr>
              <tr>
                <td><strong>Port:</strong></td>
                <td>3001</td>
              </tr>
              <tr>
                <td><strong>Framework:</strong></td>
                <td>React 18.3.1 + TypeScript</td>
              </tr>
              <tr>
                <td><strong>Build Tool:</strong></td>
                <td>Vite + Module Federation</td>
              </tr>
              <tr>
                <td><strong>Loaded At:</strong></td>
                <td>{new Date().toLocaleString()}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default App;
