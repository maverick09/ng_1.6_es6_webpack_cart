import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createInstance } from '@module-federation/enhanced/runtime';
import type { FederationRuntimePlugin } from '@module-federation/enhanced/runtime';

// Create federation instance FIRST - before any React code
export const federationInstance = createInstance({
  name: 'shell',
  remotes: [],
  shared: {
    react: {
      version: '18.3.1',
      lib: () => import('react'),
      shareConfig: {
        singleton: true,
        eager: true,
        requiredVersion: '^18.0.0',
        strictVersion: false,
      },
    },
    'react-dom': {
      version: '18.3.1',
      lib: () => import('react-dom'),
      shareConfig: {
        singleton: true,
        eager: true,
        requiredVersion: '^18.0.0',
        strictVersion: false,
      },
    },
    'react-router-dom': {
      version: '6.22.0',
      lib: () => import('react-router-dom'),
      shareConfig: {
        singleton: true,
        requiredVersion: '^6.0.0',
        strictVersion: false,
      },
    },
  },
});

console.log('✅ Federation instance created');

// Then dynamically import and render the App
import('./App').then(({ default: App }) => {
  const rootElement = document.getElementById('root');
  if (!rootElement) throw new Error('Root element not found');

  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>
  );

  console.log('✅ App rendered');
});
