import { BrowserRouter, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { federationInstance } from './main';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <div className="app-container">
        <header className="app-header">
          <h1>🏠 Shell App - Module Federation</h1>
          <p>Dynamic Remote Loading with TypeScript + Vite + Nx</p>
        </header>

        <nav className="app-nav">
          <Link to="/" className="nav-link">Home</Link>
          <Link to="/remote" className="nav-link">Remote App</Link>
        </nav>

        <main className="app-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/remote" element={<RemoteAppRoute />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </main>

        <footer className="app-footer">
          <p>Port: 3000 | Shell Application</p>
        </footer>
      </div>
    </BrowserRouter>
  );
}

function Home() {
  const navigate = useNavigate();

  return (
    <div className="home-content">
      <h2>Welcome to the Shell App</h2>
      <p>This is a demonstration of Module Federation with:</p>
      <ul>
        <li>✅ TypeScript</li>
        <li>✅ React 18.3.1</li>
        <li>✅ Vite</li>
        <li>✅ Nx Workspace</li>
        <li>✅ Dynamic Remote Loading with createInstance()</li>
        <li>✅ React Router</li>
      </ul>
      
      <button 
        onClick={() => navigate('/remote')}
        className="cta-button"
      >
        Load Remote App →
      </button>

      <div className="info-box">
        <strong>How it works:</strong>
        <p>When you click the button, the shell will dynamically register and load the remote module at runtime using Module Federation's createInstance API.</p>
      </div>
    </div>
  );
}

function RemoteAppRoute() {
  const [isRegistered, setIsRegistered] = useState(false);
  const [Component, setComponent] = useState<React.ComponentType | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingState, setLoadingState] = useState<string>('Initializing...');

  useEffect(() => {
    let mounted = true;

    const loadRemote = async () => {
      try {
        setLoadingState('🔄 Registering remote application...');
        console.log('🔄 Starting remote registration');

        // Register the remote
        await federationInstance.registerRemotes([
          {
            name: 'remoteApp',
            entry: 'http://localhost:3001/remoteEntry.js',
            alias: 'remoteApp',
            type: 'module',
          },
        ]);

        if (!mounted) return;

        console.log('✅ Remote registered successfully');
        setIsRegistered(true);
        setLoadingState('🔄 Loading remote module...');

        // Small delay to ensure registration is fully complete
        await new Promise(resolve => setTimeout(resolve, 100));

        // Load the remote module
        console.log('🔄 Loading remote module: remoteApp/./App');
        const module = await federationInstance.loadRemote<any>('remoteApp/./App');

        if (!mounted) return;

        console.log('✅ Module loaded successfully:', module);
        
        const RemoteComponent = module?.default || module;
        
        if (!RemoteComponent) {
          throw new Error('Remote module did not export a component');
        }

        setComponent(() => RemoteComponent);
        setLoadingState('✅ Complete');

      } catch (err) {
        if (!mounted) return;
        
        console.error('❌ Failed to load remote:', err);
        setError(err instanceof Error ? err.message : String(err));
        setLoadingState('❌ Failed');
      }
    };

    loadRemote();

    return () => {
      mounted = false;
    };
  }, []);

  if (error) {
    return (
      <div className="error-container">
        <h2>❌ Error Loading Remote</h2>
        <p className="error-message">{error}</p>
        <div className="error-details">
          <h3>Troubleshooting:</h3>
          <ol>
            <li>Ensure the remote app is running on port 3001</li>
            <li>Check that http://localhost:3001/remoteEntry.js is accessible</li>
            <li>Verify React versions match (18.3.1)</li>
            <li>Check the browser console for detailed errors</li>
          </ol>
        </div>
        <button onClick={() => window.location.reload()} className="retry-button">
          Retry
        </button>
      </div>
    );
  }

  if (!Component) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <h2>{loadingState}</h2>
        <div className="loading-details">
          <p>Status: {isRegistered ? '✅ Registered' : '⏳ Registering'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="remote-wrapper">
      <div className="remote-info">
        <p>✅ Remote module loaded successfully from port 3001</p>
      </div>
      <Component />
    </div>
  );
}

function NotFound() {
  return (
    <div className="not-found">
      <h2>404 - Page Not Found</h2>
      <Link to="/">Go Home</Link>
    </div>
  );
}

export default App;
