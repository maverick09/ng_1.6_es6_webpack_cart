# 🏗️ Architecture Deep Dive

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         Browser Window                           │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │          window.__RUNTIME__ (from runtime-config.js)      │  │
│  │  {                                                         │  │
│  │    remotes: {                                             │  │
│  │      product: "http://localhost:3001",                    │  │
│  │      cart: "http://localhost:3002",                       │  │
│  │      user: "http://localhost:3003"                        │  │
│  │    }                                                       │  │
│  │  }                                                         │  │
│  └──────────────────────────────────────────────────────────┘  │
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │                    Shell App (Port 3000)                  │  │
│  │                                                            │  │
│  │  ┌────────────────────────────────────────────────────┐  │  │
│  │  │         Runtime Plugin (URL Override)              │  │  │
│  │  │  beforeRequest() {                                 │  │  │
│  │  │    url = window.__RUNTIME__.remotes[name]          │  │  │
│  │  │  }                                                 │  │  │
│  │  └────────────────────────────────────────────────────┘  │  │
│  │                         ↓                                  │  │
│  │  ┌────────────────────────────────────────────────────┐  │  │
│  │  │              React Router                           │  │  │
│  │  │  - /products → product/ProductList                 │  │  │
│  │  │  - /cart → cart/Cart                              │  │  │
│  │  │  - /profile → user/Profile                        │  │  │
│  │  └────────────────────────────────────────────────────┘  │  │
│  │                         ↓                                  │  │
│  │  ┌────────────────────────────────────────────────────┐  │  │
│  │  │           Shared State (Zustand)                   │  │  │
│  │  │  - useAuthStore()                                  │  │  │
│  │  │  - useCartStore()                                  │  │  │
│  │  └────────────────────────────────────────────────────┘  │  │
│  │                         ↓                                  │  │
│  │  ┌────────────────────────────────────────────────────┐  │  │
│  │  │             Event Bus                              │  │  │
│  │  │  - emit('cart:updated')                           │  │  │
│  │  │  - on('user:login')                               │  │  │
│  │  └────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ↓                                    │
│         ┌────────────────────┼────────────────────┐             │
│         ↓                    ↓                     ↓             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐     │
│  │   Product    │    │     Cart     │    │     User     │     │
│  │     MFE      │    │     MFE      │    │     MFE      │     │
│  │  (Port 3001) │    │ (Port 3002)  │    │ (Port 3003)  │     │
│  │              │    │              │    │              │     │
│  │ Exposes:     │    │ Exposes:     │    │ Exposes:     │     │
│  │ - ProductList│    │ - Cart       │    │ - Profile    │     │
│  │ - Detail     │    │ - Checkout   │    │ - Settings   │     │
│  └──────────────┘    └──────────────┘    └──────────────┘     │
└─────────────────────────────────────────────────────────────────┘
```

---

## Request Flow

### 1. Application Startup

```
User opens browser
      ↓
Load index.html
      ↓
Execute: <script src="/runtime-config.js"></script>
      ↓
window.__RUNTIME__ populated
      ↓
Load: <script src="/src/main.tsx"></script>
      ↓
Vite processes module-federation.config.ts
      ↓
Runtime Plugin registered automatically
      ↓
React app starts
```

### 2. Navigating to a Route

```
User clicks "Products" link
      ↓
React Router matches /products route
      ↓
Route config: { remote: 'product', module: './ProductList' }
      ↓
React.lazy(() => import('product/ProductList'))
      ↓
Module Federation intercepts import
      ↓
Runtime Plugin beforeRequest() called
      ↓
Plugin reads window.__RUNTIME__.remotes.product
      ↓
URL override: "http://localhost:3001/remoteEntry.js"
      ↓
Fetch remote entry
      ↓
Load ProductList component
      ↓
Render in React Suspense
      ↓
Component displayed to user
```

### 3. Cross-MFE Communication

```
User adds product to cart (in Product MFE)
      ↓
useCartStore().addItem(productId, quantity)
      ↓
Store updates cart state
      ↓
Store emits event: eventBus.emit('cart:updated', cart)
      ↓
Cart MFE listening: eventBus.on('cart:updated', updateUI)
      ↓
Cart icon updates in header (Shell)
      ↓
All subscribed MFEs receive update
```

---

## Module Federation Flow

### Build Time

```
Shell app builds with module-federation.config.ts
      ↓
Vite plugin processes config
      ↓
Creates federation runtime
      ↓
Registers runtime plugin
      ↓
Builds shell bundle with federation metadata
```

### Runtime

```
Browser loads shell
      ↓
Federation runtime initializes (automatic)
      ↓
Runtime plugin hooks registered
      ↓
Import request: import('product/ProductList')
      ↓
Plugin intercepts: beforeRequest()
      ↓
Reads: window.__RUNTIME__.remotes.product
      ↓
Overrides URL to runtime value
      ↓
Fetches: http://localhost:3001/remoteEntry.js
      ↓
Loads remote module
      ↓
Returns ProductList component
```

---

## Shared Dependencies Flow

```
Shell defines versions:
  react: ^18.3.1 (singleton)
  react-dom: ^18.3.1 (singleton)
      ↓
Product MFE imports React
      ↓
Module Federation checks: Is React already loaded?
      ↓
YES → Use Shell's React instance
      ↓
NO → Load React from Product MFE
      ↓
Result: Single React instance shared across all MFEs
```

---

## State Management Flow

### Zustand Store

```
Shell initializes stores:
  - useAuthStore
  - useCartStore
      ↓
Product MFE imports: import { useCartStore } from '@enterprise/shared-store'
      ↓
Shared dependency resolution
      ↓
Product MFE gets same store instance as Shell
      ↓
State updates propagate to all subscribers
```

### Event Bus

```
MFE A: eventBus.emit('cart:updated', data)
      ↓
Event Bus central dispatcher
      ↓
Notify all subscribers
      ↓
MFE B: eventBus.on('cart:updated', callback)
      ↓
Callback executed with data
      ↓
MFE B updates UI
```

---

## Configuration Flow

### Development

```
.env.local (defines URLs)
      ↓
npm run generate:config
      ↓
scripts/generate-runtime-config.js
      ↓
Reads process.env variables
      ↓
Generates: apps/shell/public/runtime-config.js
      ↓
Content: window.__RUNTIME__ = { remotes: {...} }
      ↓
Loaded by browser before React
      ↓
Available to runtime plugin
```

### Production

```
.env.production (production URLs)
      ↓
NODE_ENV=production npm run generate:config
      ↓
Generates runtime-config.js with prod URLs
      ↓
npm run build:prod
      ↓
Builds all apps with production config
      ↓
Deploy: Shell + each MFE to their URLs
      ↓
Shell loads from production URLs
```

---

## Error Handling Flow

```
Component throws error
      ↓
React Error Boundary catches
      ↓
ErrorBoundary component displays fallback UI
      ↓
User sees friendly error message
      ↓
Option to retry
      ↓
On retry: Reset error state
      ↓
Re-render component
```

---

## Routing Decision Flow

```
User navigates to /products/:id
      ↓
React Router matches route
      ↓
getRouteByPath('/products/123')
      ↓
Returns: { remote: 'product', module: './ProductDetail', meta: {...} }
      ↓
Check meta.requiresAuth
      ↓
If true: Check useAuthStore().isAuthenticated
      ↓
If false: Redirect to /login
      ↓
If true: Load component
      ↓
React.lazy(() => import('product/ProductDetail'))
      ↓
Runtime plugin overrides URL
      ↓
Component loads and renders
```

---

## Key Differences from Traditional MFE

### Traditional (Manual Init)

```
App starts
      ↓
Call: init({ name: 'shell', remotes: [...] })
      ↓
Timing issues possible here
      ↓
Wait for init to complete
      ↓
Call: loadRemote('product/Module')
      ↓
Manual async handling
      ↓
Errors: "createInstance first"
```

### This Approach (Automatic)

```
App starts
      ↓
Vite plugin auto-initializes Module Federation
      ↓
Runtime plugin registered in config
      ↓
Normal import: import('product/Module')
      ↓
Plugin intercepts automatically
      ↓
URL override happens transparently
      ↓
Component loads
      ↓
No manual handling needed
```

---

## Performance Optimization

### Code Splitting

```
Shell loads → Small bundle
      ↓
User navigates to /products
      ↓
Lazy load Product MFE
      ↓
Only loads when needed
      ↓
Shared deps not duplicated
```

### Caching

```
Browser caches remoteEntry.js
      ↓
Subsequent visits load from cache
      ↓
Only changed chunks re-downloaded
      ↓
Fast navigation between MFEs
```

---

## Security Considerations

### CORS

```
Shell: http://localhost:3000
Product MFE: http://localhost:3001
      ↓
Vite dev server has CORS enabled
      ↓
Production: Ensure CORS headers set
      ↓
Same-origin or proper CORS policy
```

### Authentication

```
User logs in
      ↓
Token stored in localStorage
      ↓
API client reads token
      ↓
All API requests include token
      ↓
401 → Clear auth, redirect to login
```

---

This architecture provides:
✅ Scalability (add MFEs easily)
✅ Maintainability (clean separation)
✅ Reliability (no init errors)
✅ Performance (lazy loading, sharing)
✅ Developer Experience (normal React code)
