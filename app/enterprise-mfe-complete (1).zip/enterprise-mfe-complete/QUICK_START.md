# 🚀 Quick Start Guide

## What You Have

A **complete, production-ready enterprise micro frontend platform** with:

✅ Runtime URL configuration (no rebuilds for env changes)  
✅ Clean separation with shared libraries  
✅ Type-safe TypeScript throughout  
✅ Shell controls all dependency versions  
✅ Event bus for cross-MFE communication  
✅ Zustand for global state  
✅ Error boundaries and loading states

---

## File Structure Overview

```
enterprise-mfe/
├── apps/
│   ├── shell/              # Main host app (Port 3000)
│   └── product-mfe/        # Product micro frontend (Port 3001)
│
├── libs/
│   ├── shared/
│   │   ├── types/          # TypeScript types
│   │   ├── constants/      # Constants
│   │   ├── utils/          # Helper functions
│   │   ├── api/            # API client
│   │   └── store/          # Zustand stores + Event Bus
│   └── features/
│       └── routing/        # Route configuration
│
├── scripts/
│   └── generate-runtime-config.js
│
├── .env.local              # Dev environment
├── .env.production         # Prod environment
└── README.md              # Full documentation
```

---

## Getting Started (5 Minutes)

### Step 1: Install Dependencies

```bash
cd enterprise-mfe
npm install
```

### Step 2: Generate Runtime Config

```bash
npm run generate:config
```

This creates `apps/shell/public/runtime-config.js` from `.env.local`

### Step 3: Start Development

```bash
# Option A: Start all apps at once
npm run dev

# Option B: Start individually
npm run dev:shell      # Port 3000
npm run dev:product    # Port 3001
```

### Step 4: Open Browser

Visit `http://localhost:3000` and you'll see:
- Home page with platform info
- Header navigation
- Product list (click to view details)

---

## How It Works (The Magic! ✨)

### 1. Runtime URL Override (No Manual init!)

**Traditional approach** (buggy):
```typescript
// ❌ OLD WAY - Causes "createInstance first" errors
init({ name: 'shell', remotes: [...] });
const Component = await loadRemote('product/Module');
```

**This approach** (stable):
```typescript
// ✅ NEW WAY - Build-time config + runtime URL override
// In runtime plugin (automatic):
beforeRequest(args) {
  const remoteName = args.id.split('/')[0];
  const runtimeUrl = window.__RUNTIME__.remotes[remoteName];
  return { ...args, url: `${runtimeUrl}/remoteEntry.js` };
}

// In your code (normal React):
import ProductList from 'product/ProductList';  // Just works!
```

**Key differences:**
- ✅ No manual `init()` or `loadRemote()` calls
- ✅ Normal React.lazy imports
- ✅ URLs from `window.__RUNTIME__` (generated from .env)
- ✅ No timing issues or initialization errors

### 2. Configuration Flow

```
.env.local
    ↓
generate-runtime-config.js
    ↓
public/runtime-config.js (window.__RUNTIME__)
    ↓
Runtime Plugin (intercepts requests)
    ↓
Overrides URLs dynamically
```

### 3. Shared Libraries

All MFEs import from shared libraries:

```typescript
// In any MFE:
import { Product } from '@enterprise/shared-types';
import { formatCurrency } from '@enterprise/shared-utils';
import { useAuthStore } from '@enterprise/shared-store';
import { productsApi } from '@enterprise/shared-api';
```

---

## Key Files to Understand

### 1. Runtime Plugin (`apps/shell/src/plugins/runtimePlugin.ts`)
```typescript
// This is the magic! It overrides URLs at runtime
beforeRequest(args) {
  const remoteName = args.id.split('/')[0];
  const runtimeUrl = getRemoteUrl(remoteName);
  return { ...args, url: `${runtimeUrl}/remoteEntry.js` };
}
```

### 2. Route Configuration (`libs/features/routing/src/config.ts`)
```typescript
// All routes defined in one place
export const microFrontendConfig = [
  {
    name: 'product',
    routes: [
      {
        path: '/products',
        remote: 'product',
        module: './ProductList',
        meta: { title: 'Products', requiresAuth: false },
      },
    ],
  },
];
```

### 3. Module Federation Config (`apps/shell/module-federation.config.ts`)
```typescript
export default {
  name: 'shell',
  remotes: {
    product: { entry: 'http://localhost:3001/remoteEntry.js' },
  },
  shared: { react: { singleton: true }, /* ... */ },
  runtimePlugins: ['./src/plugins/runtimePlugin.ts'], // ← Key!
};
```

---

## Adding a New Micro Frontend (10 Minutes)

Let's add a "Cart" MFE:

### 1. Create Structure

```bash
mkdir -p apps/cart-mfe/src/components
```

### 2. Create `apps/cart-mfe/module-federation.config.ts`

```typescript
export default {
  name: 'cart',
  filename: 'remoteEntry.js',
  exposes: {
    './Cart': './src/components/Cart.tsx',
  },
  shared: {
    react: { singleton: true, requiredVersion: '^18.3.1' },
    'react-dom': { singleton: true, requiredVersion: '^18.3.1' },
  },
};
```

### 3. Create `apps/cart-mfe/vite.config.ts`

```typescript
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { federation } from '@module-federation/vite';
import moduleFederationConfig from './module-federation.config';

export default defineConfig({
  plugins: [react(), federation(moduleFederationConfig)],
  server: { port: 3002, cors: true },
});
```

### 4. Create Component `apps/cart-mfe/src/components/Cart.tsx`

```typescript
const Cart = () => {
  return <div><h1>Shopping Cart</h1></div>;
};
export default Cart;
```

### 5. Add to `.env.local`

```bash
VITE_REMOTE_CART_URL=http://localhost:3002
```

### 6. Update `libs/features/routing/src/config.ts`

```typescript
{
  name: 'cart',
  routes: [{
    path: '/cart',
    remote: 'cart',
    module: './Cart',
    meta: { title: 'Cart', requiresAuth: true },
  }],
}
```

### 7. Update `apps/shell/module-federation.config.ts`

```typescript
remotes: {
  product: { entry: 'http://localhost:3001/remoteEntry.js' },
  cart: { entry: 'http://localhost:3002/remoteEntry.js' }, // ← Add
},
```

### 8. Regenerate config & restart

```bash
npm run generate:config
npm run dev
```

Done! Visit `http://localhost:3000/cart`

---

## Common Tasks

### Change Environment

```bash
# 1. Edit .env.production
# 2. Regenerate config
NODE_ENV=production npm run generate:config
# 3. Build
npm run build:prod
```

### Add a New Route

Edit `libs/features/routing/src/config.ts`:

```typescript
{
  path: '/new-page',
  remote: 'product',
  module: './NewComponent',
  meta: { title: 'New Page', showInNav: true },
}
```

### Share State Across MFEs

Use Zustand stores in `libs/shared/store/`:

```typescript
// In any MFE:
import { useAuthStore } from '@enterprise/shared-store';

const { user, logout } = useAuthStore();
```

### Emit Cross-MFE Events

```typescript
import { eventBus } from '@enterprise/shared-store';

// Emit
eventBus.emit('cart:updated', cartData);

// Listen
eventBus.on('cart:updated', (data) => {
  console.log('Cart updated!', data);
});
```

---

## Troubleshooting

### "Cannot find module 'product/ProductList'"

**Fix**: Add TypeScript declaration in `apps/shell/src/types/remotes.d.ts`:

```typescript
declare module 'product/ProductList' {
  const ProductList: React.ComponentType;
  export default ProductList;
}
```

### MFE not loading

1. Is the MFE server running? Check `http://localhost:3001/remoteEntry.js`
2. Is `runtime-config.js` loaded? Check Network tab
3. Check browser console for errors

### Version conflicts

Ensure all MFEs use the same versions as shell:

```typescript
// All module-federation.config.ts files:
shared: {
  react: { singleton: true, requiredVersion: '^18.3.1' },
}
```

---

## Next Steps

1. ✅ **Explore the code** - Start with `apps/shell/src/App.tsx`
2. ✅ **Add a new MFE** - Follow the guide above
3. ✅ **Read full docs** - `README.md` has everything
4. ✅ **Customize** - Update branding, add features
5. ✅ **Deploy** - Follow deployment guide in README

---

## Key Advantages of This Approach

1. **No init() errors** - Build-time config + runtime URL override
2. **Normal React code** - Use imports, not loadRemote()
3. **Type-safe** - Full TypeScript support
4. **Flexible** - Change URLs without rebuilding
5. **Scalable** - Add MFEs easily
6. **Enterprise-ready** - Error boundaries, state management, routing

---

## Questions?

Check:
1. `README.md` - Full documentation
2. Code comments - Every file is documented
3. Examples - Product MFE is a complete example

---

**You're ready to build! 🎉**
