# 🎯 Getting Started - Enterprise Micro Frontend Application

## What You Get

A **production-ready, enterprise-grade micro frontend setup** that:
- ✅ Uses Module Federation WITHOUT manual `init()` or `loadRemote()` 
- ✅ Has runtime URL configuration via `window.__RUNTIME__`
- ✅ Uses standard React patterns (lazy, Suspense)
- ✅ Includes complete type safety
- ✅ Has shared libraries for common code
- ✅ Includes authentication & authorization
- ✅ Has inter-MFE communication (event bus)
- ✅ NO "createInstance first" errors
- ✅ NO timing/initialization issues

---

## 🚀 30-Second Setup

```bash
# 1. Install
npm install

# 2. Generate config
npm run generate:config

# 3. Start everything
npm run start:all

# 4. Open browser
# http://localhost:3000
```

Done! All 4 apps running, fully integrated.

---

## 📂 What's Included

### Applications (apps/)
- **shell** (Port 3000) - Host application with routing
- **product** (Port 3001) - Product catalog micro frontend
- **cart** (Port 3002) - Shopping cart & checkout
- **user** (Port 3003) - User profile & settings

### Shared Libraries (libs/)
- **shared-types** - TypeScript types for all apps
- **shared-utils** - Runtime config, API client, event bus, storage
- **shared-ui** - UI components, layouts, HOCs, contexts
- **mfe-config** - Centralized routing & configuration

---

## 🔑 Key Concept: Runtime URL Override

### How It Works (Simple!)

1. **Set Environment Variables**
   ```env
   # .env.local
   VITE_REMOTE_PRODUCT_URL=http://localhost:3001
   ```

2. **Generate Runtime Config**
   ```bash
   npm run generate:config
   ```
   Creates:
   ```javascript
   window.__RUNTIME__ = {
     remotes: {
       product: "http://localhost:3001"
     }
   }
   ```

3. **Plugin Overrides URLs**
   Runtime plugin intercepts remote requests and replaces URLs

4. **Use Normal Imports**
   ```typescript
   import ProductList from 'product/ProductList';
   <Route path="/products" element={<ProductList />} />
   ```

**That's it!** No manual init, no loadRemote, no complexity.

---

## 📝 Common Tasks

### Start Development
```bash
npm run start:all
# or individually:
npm run dev:shell
npm run dev:product
npm run dev:cart
npm run dev:user
```

### Build for Production
```bash
npm run build:all
```

### Preview Production Build
```bash
npm run preview:shell
```

### Change Environment URLs
1. Edit `.env.local` or `.env.production`
2. Run `npm run generate:config`
3. Restart apps

---

## 🎨 Project Structure

```
enterprise-mfe/
├── apps/
│   ├── shell/              # Host (imports all remotes)
│   ├── product/            # Remote (exposes ProductList, etc.)
│   ├── cart/               # Remote (exposes Cart, Checkout, etc.)
│   └── user/               # Remote (exposes Profile, Settings, etc.)
│
├── libs/
│   ├── shared-types/       # TypeScript interfaces
│   ├── shared-utils/       # Utilities (API, events, storage, runtime)
│   ├── shared-ui/          # Components (Loading, ErrorBoundary, etc.)
│   └── mfe-config/         # Configuration (routes, plugin)
│
└── tools/scripts/
    └── generate-runtime-config.js
```

---

## 🔐 Authentication

### Using withAuth HOC
```typescript
import { withAuth } from '@enterprise-mfe/shared-ui';

export default withAuth(ProfilePage, {
  requiredRoles: ['user'],
  redirectTo: '/login'
});
```

### Using useAuth Hook
```typescript
import { useAuth } from '@enterprise-mfe/shared-ui';

function MyComponent() {
  const { user, isAuthenticated, logout } = useAuth();
  
  return <div>Welcome {user?.firstName}</div>;
}
```

---

## 📡 Inter-MFE Communication

```typescript
import { eventBus, MFE_EVENTS } from '@enterprise-mfe/shared-utils';

// Publish event
eventBus.emit(MFE_EVENTS.CART_ITEM_ADDED, { productId, quantity });

// Subscribe to event
eventBus.on(MFE_EVENTS.CART_ITEM_ADDED, (event) => {
  console.log('Item added:', event.payload);
});
```

---

## 🆕 Adding a New Remote

### 1. Create Directory
```bash
mkdir -p apps/my-remote/src/components
```

### 2. Add Environment Variable
```bash
# .env.local
VITE_REMOTE_MY_REMOTE_URL=http://localhost:3004
```

### 3. Update Configuration Files

**libs/mfe-config/src/config/microFrontendConfig.ts**
```typescript
{
  name: 'myRemote',
  routes: [{
    path: '/my-feature',
    title: 'My Feature',
    remote: 'myRemote',
    module: './MyComponent',
  }]
}
```

**apps/shell/module-federation.config.ts**
```typescript
remotes: {
  myRemote: {
    entry: 'http://localhost:3004/remoteEntry.js',
    type: 'module',
  }
}
```

### 4. Create Type Declaration

**apps/shell/src/types/remotes.d.ts**
```typescript
declare module 'myRemote/MyComponent' {
  const MyComponent: React.ComponentType;
  export default MyComponent;
}
```

### 5. Import in Shell

**apps/shell/src/App.tsx**
```typescript
const MyComponent = lazy(() => import('myRemote/MyComponent'));
```

---

## 🐛 Troubleshooting

### Config Not Loading
```bash
# Check if runtime-config.js exists
ls apps/shell/public/runtime-config.js

# Regenerate if missing
npm run generate:config
```

### Remote Not Loading
1. Check remote is running: `npm run dev:product`
2. Check browser console for errors
3. Check network tab for 404s
4. Verify `exposes` in remote's module-federation.config.ts

### Type Errors
1. Add declaration in `apps/shell/src/types/remotes.d.ts`
2. Restart TypeScript server (VS Code: Cmd+Shift+P → "Restart TS Server")

---

## 📚 Documentation

- **README.md** - Complete project overview
- **SETUP_GUIDE.md** - Detailed setup instructions
- **QUICK_REFERENCE.md** - Commands and patterns
- **COMPARISON.md** - Old vs new approach
- **GETTING_STARTED.md** - This file!

---

## ✨ Key Features

### Clean Architecture
- Separation of concerns
- Shared libraries for common code
- Each MFE is independent

### Type Safety
- Full TypeScript support
- Type declarations for all remotes
- Shared types across apps

### Developer Experience
- Hot Module Replacement works
- Standard React patterns
- No initialization complexity
- Easy debugging

### Production Ready
- Environment-specific config
- Error boundaries
- Loading states
- Authentication & authorization

---

## 🎯 Next Steps

1. **Explore the code** - Start with `apps/shell/src/App.tsx`
2. **Add a feature** - Create a new component in a remote
3. **Customize** - Update routes, add pages, style components
4. **Deploy** - Build and deploy each app independently

---

## 💡 Pro Tips

1. Always run `npm run generate:config` after changing .env files
2. Keep remotes simple - one domain per remote
3. Use shared libraries for truly common code
4. Add type declarations immediately when creating new exposes
5. Check browser console for runtime plugin logs

---

## 🤝 Support

- Check **QUICK_REFERENCE.md** for common commands
- Check **COMPARISON.md** to understand the approach
- Check **SETUP_GUIDE.md** for detailed instructions

---

**You're all set! Happy coding! 🚀**
