import api from './client';
import type { User, Product, Cart, Order, PaginatedResponse, PaginationParams } from '@enterprise/shared-types';
import { API_ENDPOINTS } from '@enterprise/shared-constants';

/**
 * Authentication API Service
 */
export const authApi = {
  login: async (email: string, password: string): Promise<{ user: User; token: string }> => {
    return api.post(API_ENDPOINTS.AUTH.LOGIN, { email, password });
  },

  logout: async (): Promise<void> => {
    return api.post(API_ENDPOINTS.AUTH.LOGOUT);
  },

  getMe: async (): Promise<User> => {
    return api.get(API_ENDPOINTS.AUTH.ME);
  },

  refreshToken: async (): Promise<{ token: string }> => {
    return api.post(API_ENDPOINTS.AUTH.REFRESH);
  },
};

/**
 * Products API Service
 */
export const productsApi = {
  getProducts: async (params?: PaginationParams): Promise<PaginatedResponse<Product>> => {
    return api.get(API_ENDPOINTS.PRODUCTS.LIST, { params });
  },

  getProduct: async (id: string): Promise<Product> => {
    return api.get(API_ENDPOINTS.PRODUCTS.DETAIL(id));
  },

  searchProducts: async (query: string, params?: PaginationParams): Promise<PaginatedResponse<Product>> => {
    return api.get(API_ENDPOINTS.PRODUCTS.SEARCH, { 
      params: { ...params, q: query } 
    });
  },
};

/**
 * Cart API Service
 */
export const cartApi = {
  getCart: async (): Promise<Cart> => {
    return api.get(API_ENDPOINTS.CART.GET);
  },

  addItem: async (productId: string, quantity: number): Promise<Cart> => {
    return api.post(API_ENDPOINTS.CART.ADD_ITEM, { productId, quantity });
  },

  updateItem: async (itemId: string, quantity: number): Promise<Cart> => {
    return api.put(API_ENDPOINTS.CART.UPDATE_ITEM(itemId), { quantity });
  },

  removeItem: async (itemId: string): Promise<Cart> => {
    return api.delete(API_ENDPOINTS.CART.REMOVE_ITEM(itemId));
  },

  clearCart: async (): Promise<void> => {
    return api.delete(API_ENDPOINTS.CART.CLEAR);
  },
};

/**
 * Orders API Service
 */
export const ordersApi = {
  getOrders: async (params?: PaginationParams): Promise<PaginatedResponse<Order>> => {
    return api.get(API_ENDPOINTS.ORDERS.LIST, { params });
  },

  getOrder: async (id: string): Promise<Order> => {
    return api.get(API_ENDPOINTS.ORDERS.DETAIL(id));
  },

  createOrder: async (data: any): Promise<Order> => {
    return api.post(API_ENDPOINTS.ORDERS.CREATE, data);
  },
};

/**
 * User API Service
 */
export const userApi = {
  getProfile: async (): Promise<User> => {
    return api.get(API_ENDPOINTS.USER.PROFILE);
  },

  updateProfile: async (data: Partial<User>): Promise<User> => {
    return api.put(API_ENDPOINTS.USER.UPDATE, data);
  },

  getSettings: async (): Promise<any> => {
    return api.get(API_ENDPOINTS.USER.SETTINGS);
  },

  updateSettings: async (data: any): Promise<any> => {
    return api.put(API_ENDPOINTS.USER.SETTINGS, data);
  },
};
