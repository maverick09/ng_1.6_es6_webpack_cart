import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
import type { ApiResponse, ApiError } from '@enterprise/shared-types';
import { getApiBaseUrl } from '@enterprise/shared-utils';
import { authStorage } from '@enterprise/shared-utils';
import { HTTP_STATUS } from '@enterprise/shared-constants';

/**
 * Create and configure axios instance
 */
const createApiClient = (): AxiosInstance => {
  const client = axios.create({
    baseURL: getApiBaseUrl(),
    timeout: 30000,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Request interceptor - Add auth token
  client.interceptors.request.use(
    (config) => {
      const token = authStorage.getToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      
      console.log(`🌐 API Request: ${config.method?.toUpperCase()} ${config.url}`);
      return config;
    },
    (error) => {
      console.error('❌ Request error:', error);
      return Promise.reject(error);
    }
  );

  // Response interceptor - Handle errors
  client.interceptors.response.use(
    (response) => {
      console.log(`✅ API Response: ${response.config.url}`, response.status);
      return response;
    },
    async (error: AxiosError) => {
      console.error('❌ API Error:', error.message);

      if (error.response) {
        const status = error.response.status;

        // Handle 401 Unauthorized - Token expired
        if (status === HTTP_STATUS.UNAUTHORIZED) {
          console.warn('🔒 Unauthorized - Clearing auth data');
          authStorage.clear();
          window.location.href = '/login';
        }

        // Handle 403 Forbidden
        if (status === HTTP_STATUS.FORBIDDEN) {
          console.warn('🚫 Forbidden - Insufficient permissions');
        }

        // Handle 404 Not Found
        if (status === HTTP_STATUS.NOT_FOUND) {
          console.warn('🔍 Not Found');
        }

        // Handle 500 Internal Server Error
        if (status === HTTP_STATUS.INTERNAL_SERVER_ERROR) {
          console.error('💥 Internal Server Error');
        }
      } else if (error.request) {
        console.error('📡 Network error - No response received');
      }

      return Promise.reject(formatError(error));
    }
  );

  return client;
};

/**
 * Format axios error to ApiError
 */
const formatError = (error: AxiosError): ApiError => {
  if (error.response) {
    return {
      message: (error.response.data as any)?.message || error.message,
      code: (error.response.data as any)?.code || 'API_ERROR',
      statusCode: error.response.status,
      details: error.response.data,
    };
  }

  return {
    message: error.message,
    code: 'NETWORK_ERROR',
    statusCode: 0,
  };
};

// Create singleton instance
export const apiClient = createApiClient();

/**
 * Generic API request wrapper
 */
export const api = {
  get: async <T = any>(url: string, config?: AxiosRequestConfig): Promise<T> => {
    const response = await apiClient.get<ApiResponse<T>>(url, config);
    return response.data.data;
  },

  post: async <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => {
    const response = await apiClient.post<ApiResponse<T>>(url, data, config);
    return response.data.data;
  },

  put: async <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => {
    const response = await apiClient.put<ApiResponse<T>>(url, data, config);
    return response.data.data;
  },

  patch: async <T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> => {
    const response = await apiClient.patch<ApiResponse<T>>(url, data, config);
    return response.data.data;
  },

  delete: async <T = any>(url: string, config?: AxiosRequestConfig): Promise<T> => {
    const response = await apiClient.delete<ApiResponse<T>>(url, config);
    return response.data.data;
  },
};

export default api;
