// ============================================================================
// Core Domain Types
// ============================================================================

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  avatar?: string;
  role: UserRole;
  createdAt: string;
  updatedAt: string;
}

export enum UserRole {
  ADMIN = 'admin',
  USER = 'user',
  GUEST = 'guest',
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  imageUrl: string;
  category: string;
  stock: number;
  rating: number;
  reviews: number;
  createdAt: string;
  updatedAt: string;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  quantity: number;
  price: number;
  subtotal: number;
}

export interface Cart {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  itemCount: number;
  updatedAt: string;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: OrderStatus;
  shippingAddress: Address;
  paymentMethod: PaymentMethod;
  createdAt: string;
  updatedAt: string;
}

export enum OrderStatus {
  PENDING = 'pending',
  CONFIRMED = 'confirmed',
  SHIPPED = 'shipped',
  DELIVERED = 'delivered',
  CANCELLED = 'cancelled',
}

export interface Address {
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

export interface PaymentMethod {
  type: 'credit_card' | 'debit_card' | 'paypal';
  last4?: string;
}

// ============================================================================
// Runtime Configuration Types
// ============================================================================

export interface RuntimeConfig {
  environment: string;
  apiBaseUrl: string;
  remotes: {
    [key: string]: string;
  };
  features: {
    enableAnalytics: boolean;
    enableErrorReporting: boolean;
  };
  version: string;
}

declare global {
  interface Window {
    __RUNTIME__: RuntimeConfig;
  }
}

// ============================================================================
// Route Configuration Types
// ============================================================================

export interface RouteMetadata {
  title: string;
  requiresAuth?: boolean;
  roles?: UserRole[];
  icon?: string;
  showInNav?: boolean;
  [key: string]: any;
}

export interface MicroFrontendRoute {
  path: string;
  remote: string;
  module: string;
  exact?: boolean;
  meta: RouteMetadata;
}

export interface MicroFrontendConfig {
  name: string;
  displayName: string;
  routes: MicroFrontendRoute[];
  errorBoundary?: boolean;
  prefetch?: boolean;
}

// ============================================================================
// API Types
// ============================================================================

export interface ApiResponse<T = any> {
  data: T;
  message?: string;
  success: boolean;
}

export interface ApiError {
  message: string;
  code: string;
  statusCode: number;
  details?: any;
}

export interface PaginationParams {
  page: number;
  limit: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// ============================================================================
// Component Props Types
// ============================================================================

export interface BaseComponentProps {
  className?: string;
  children?: React.ReactNode;
}

export interface LoadingState {
  isLoading: boolean;
  error?: string | null;
}

// ============================================================================
// Store Types
// ============================================================================

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

export interface CartState {
  cart: Cart | null;
  isLoading: boolean;
  error: string | null;
  addItem: (productId: string, quantity: number) => Promise<void>;
  removeItem: (itemId: string) => Promise<void>;
  updateQuantity: (itemId: string, quantity: number) => Promise<void>;
  clearCart: () => void;
  fetchCart: () => Promise<void>;
}

// ============================================================================
// Event Bus Types
// ============================================================================

export type EventCallback<T = any> = (data: T) => void;

export interface EventBusEvents {
  'user:login': User;
  'user:logout': void;
  'cart:updated': Cart;
  'cart:item-added': CartItem;
  'product:viewed': Product;
  'navigation:change': { path: string };
}

export type EventBusEventName = keyof EventBusEvents;
