import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import type { CartState, Cart } from '@enterprise/shared-types';
import { cartApi } from '@enterprise/shared-api';
import { eventBus } from '../events';
import { EVENTS } from '@enterprise/shared-constants';

/**
 * Cart Store
 * Manages shopping cart state and operations
 */
export const useCartStore = create<CartState>()(
  devtools(
    (set, get) => ({
      cart: null,
      isLoading: false,
      error: null,

      /**
       * Fetch cart data
       */
      fetchCart: async () => {
        set({ isLoading: true, error: null });

        try {
          const cart = await cartApi.getCart();
          set({ cart, isLoading: false });
          console.log('✅ Cart fetched successfully');
        } catch (error: any) {
          console.error('❌ Failed to fetch cart:', error);
          set({ 
            isLoading: false, 
            error: error.message || 'Failed to fetch cart',
          });
        }
      },

      /**
       * Add item to cart
       */
      addItem: async (productId: string, quantity: number) => {
        set({ isLoading: true, error: null });

        try {
          const cart = await cartApi.addItem(productId, quantity);
          set({ cart, isLoading: false });
          
          // Emit event
          eventBus.emit(EVENTS.CART_UPDATED, cart);
          
          console.log('✅ Item added to cart');
        } catch (error: any) {
          console.error('❌ Failed to add item:', error);
          set({ 
            isLoading: false, 
            error: error.message || 'Failed to add item',
          });
          throw error;
        }
      },

      /**
       * Remove item from cart
       */
      removeItem: async (itemId: string) => {
        set({ isLoading: true, error: null });

        try {
          const cart = await cartApi.removeItem(itemId);
          set({ cart, isLoading: false });
          
          // Emit event
          eventBus.emit(EVENTS.CART_UPDATED, cart);
          
          console.log('✅ Item removed from cart');
        } catch (error: any) {
          console.error('❌ Failed to remove item:', error);
          set({ 
            isLoading: false, 
            error: error.message || 'Failed to remove item',
          });
          throw error;
        }
      },

      /**
       * Update item quantity
       */
      updateQuantity: async (itemId: string, quantity: number) => {
        set({ isLoading: true, error: null });

        try {
          const cart = await cartApi.updateItem(itemId, quantity);
          set({ cart, isLoading: false });
          
          // Emit event
          eventBus.emit(EVENTS.CART_UPDATED, cart);
          
          console.log('✅ Item quantity updated');
        } catch (error: any) {
          console.error('❌ Failed to update quantity:', error);
          set({ 
            isLoading: false, 
            error: error.message || 'Failed to update quantity',
          });
          throw error;
        }
      },

      /**
       * Clear cart
       */
      clearCart: () => {
        cartApi.clearCart().catch(console.error);
        set({ cart: null });
        console.log('✅ Cart cleared');
      },
    }),
    {
      name: 'cart-store',
    }
  )
);
