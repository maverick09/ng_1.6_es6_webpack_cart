import type { EventBusEvents, EventBusEventName, EventCallback } from '@enterprise/shared-types';

/**
 * Event Bus for cross-micro-frontend communication
 * Allows different MFEs to communicate without tight coupling
 */
class EventBus {
  private events: Map<string, Set<EventCallback>>;

  constructor() {
    this.events = new Map();
  }

  /**
   * Subscribe to an event
   */
  on<K extends EventBusEventName>(
    event: K,
    callback: EventCallback<EventBusEvents[K]>
  ): () => void {
    if (!this.events.has(event)) {
      this.events.set(event, new Set());
    }

    this.events.get(event)!.add(callback);

    console.log(`📡 Subscribed to event: ${event}`);

    // Return unsubscribe function
    return () => this.off(event, callback);
  }

  /**
   * Unsubscribe from an event
   */
  off<K extends EventBusEventName>(
    event: K,
    callback: EventCallback<EventBusEvents[K]>
  ): void {
    const callbacks = this.events.get(event);
    if (callbacks) {
      callbacks.delete(callback);
      console.log(`📴 Unsubscribed from event: ${event}`);
    }
  }

  /**
   * Emit an event
   */
  emit<K extends EventBusEventName>(
    event: K,
    data: EventBusEvents[K]
  ): void {
    const callbacks = this.events.get(event);
    
    if (callbacks && callbacks.size > 0) {
      console.log(`📢 Emitting event: ${event}`, data);
      callbacks.forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in event callback for ${event}:`, error);
        }
      });
    }
  }

  /**
   * Subscribe to an event once
   */
  once<K extends EventBusEventName>(
    event: K,
    callback: EventCallback<EventBusEvents[K]>
  ): () => void {
    const wrappedCallback = (data: EventBusEvents[K]) => {
      callback(data);
      this.off(event, wrappedCallback as any);
    };

    return this.on(event, wrappedCallback as any);
  }

  /**
   * Remove all listeners for an event
   */
  removeAllListeners(event?: EventBusEventName): void {
    if (event) {
      this.events.delete(event);
      console.log(`🗑️ Removed all listeners for event: ${event}`);
    } else {
      this.events.clear();
      console.log('🗑️ Removed all event listeners');
    }
  }

  /**
   * Get listener count for an event
   */
  listenerCount(event: EventBusEventName): number {
    return this.events.get(event)?.size || 0;
  }
}

// Create singleton instance
export const eventBus = new EventBus();

// Make it available globally for micro frontends
if (typeof window !== 'undefined') {
  (window as any).__EVENT_BUS__ = eventBus;
}
