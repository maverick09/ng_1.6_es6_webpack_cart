import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import type { AuthState, User } from '@enterprise/shared-types';
import { authApi } from '@enterprise/shared-api';
import { authStorage } from '@enterprise/shared-utils';
import { eventBus } from '../events';
import { EVENTS } from '@enterprise/shared-constants';

/**
 * Authentication Store
 * Manages user authentication state and operations
 */
export const useAuthStore = create<AuthState>()(
  devtools(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      /**
       * Login user
       */
      login: async (email: string, password: string) => {
        set({ isLoading: true, error: null });

        try {
          const { user, token } = await authApi.login(email, password);
          
          // Store token
          authStorage.setToken(token);
          
          // Update state
          set({ 
            user, 
            isAuthenticated: true, 
            isLoading: false,
            error: null,
          });

          // Emit event
          eventBus.emit(EVENTS.USER_LOGIN, user);

          console.log('✅ User logged in successfully:', user.email);
        } catch (error: any) {
          console.error('❌ Login failed:', error);
          set({ 
            isLoading: false, 
            error: error.message || 'Login failed',
          });
          throw error;
        }
      },

      /**
       * Logout user
       */
      logout: () => {
        try {
          // Call logout API (fire and forget)
          authApi.logout().catch(console.error);
        } catch (error) {
          console.error('Logout API error:', error);
        }

        // Clear local state
        authStorage.clear();
        set({ 
          user: null, 
          isAuthenticated: false,
          error: null,
        });

        // Emit event
        eventBus.emit(EVENTS.USER_LOGOUT, undefined);

        console.log('✅ User logged out');
      },

      /**
       * Refresh user data
       */
      refreshUser: async () => {
        const token = authStorage.getToken();
        
        if (!token) {
          set({ isAuthenticated: false, user: null });
          return;
        }

        set({ isLoading: true });

        try {
          const user = await authApi.getMe();
          set({ 
            user, 
            isAuthenticated: true, 
            isLoading: false,
            error: null,
          });
          console.log('✅ User data refreshed');
        } catch (error: any) {
          console.error('❌ Failed to refresh user:', error);
          authStorage.clear();
          set({ 
            user: null, 
            isAuthenticated: false, 
            isLoading: false,
            error: error.message,
          });
        }
      },
    }),
    {
      name: 'auth-store',
    }
  )
);

// Initialize auth state on app load
if (typeof window !== 'undefined') {
  const token = authStorage.getToken();
  if (token) {
    useAuthStore.getState().refreshUser();
  }
}
