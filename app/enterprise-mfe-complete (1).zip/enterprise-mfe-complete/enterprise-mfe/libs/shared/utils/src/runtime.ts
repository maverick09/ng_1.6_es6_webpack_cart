import type { RuntimeConfig } from '@enterprise/shared-types';

/**
 * Get the runtime configuration from window.__RUNTIME__
 */
export const getRuntimeConfig = (): RuntimeConfig => {
  if (typeof window === 'undefined') {
    throw new Error('getRuntimeConfig can only be called in browser environment');
  }

  if (!window.__RUNTIME__) {
    console.error('❌ Runtime configuration not found!');
    console.warn('Make sure runtime-config.js is loaded before the application');
    
    // Return default configuration for development
    return {
      environment: 'development',
      apiBaseUrl: 'http://localhost:4000',
      remotes: {},
      features: {
        enableAnalytics: false,
        enableErrorReporting: false,
      },
      version: '1.0.0',
    };
  }

  return window.__RUNTIME__;
};

/**
 * Get a remote URL by name
 */
export const getRemoteUrl = (remoteName: string): string => {
  const config = getRuntimeConfig();
  const url = config.remotes[remoteName];

  if (!url) {
    console.error(`❌ Remote "${remoteName}" not found in runtime configuration`);
    console.warn('Available remotes:', Object.keys(config.remotes));
    return '';
  }

  return url;
};

/**
 * Get the remote entry URL for a specific remote
 */
export const getRemoteEntry = (remoteName: string): string => {
  const baseUrl = getRemoteUrl(remoteName);
  return baseUrl ? `${baseUrl}/remoteEntry.js` : '';
};

/**
 * Check if a feature is enabled
 */
export const isFeatureEnabled = (featureName: keyof RuntimeConfig['features']): boolean => {
  const config = getRuntimeConfig();
  return config.features[featureName] ?? false;
};

/**
 * Get the API base URL
 */
export const getApiBaseUrl = (): string => {
  const config = getRuntimeConfig();
  return config.apiBaseUrl;
};

/**
 * Get the current environment
 */
export const getEnvironment = (): string => {
  const config = getRuntimeConfig();
  return config.environment;
};

/**
 * Check if running in production
 */
export const isProduction = (): boolean => {
  return getEnvironment() === 'production';
};

/**
 * Check if running in development
 */
export const isDevelopment = (): boolean => {
  return getEnvironment() === 'development';
};
