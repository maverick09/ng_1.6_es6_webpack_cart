import { STORAGE_KEYS } from '@enterprise/shared-constants';

/**
 * Type-safe storage wrapper
 */
class StorageService {
  private storage: Storage;

  constructor(storage: Storage) {
    this.storage = storage;
  }

  /**
   * Get item from storage
   */
  get<T>(key: string): T | null {
    try {
      const item = this.storage.getItem(key);
      if (!item) return null;
      return JSON.parse(item) as T;
    } catch (error) {
      console.error(`Error reading from storage (${key}):`, error);
      return null;
    }
  }

  /**
   * Set item in storage
   */
  set<T>(key: string, value: T): void {
    try {
      this.storage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error(`Error writing to storage (${key}):`, error);
    }
  }

  /**
   * Remove item from storage
   */
  remove(key: string): void {
    try {
      this.storage.removeItem(key);
    } catch (error) {
      console.error(`Error removing from storage (${key}):`, error);
    }
  }

  /**
   * Clear all items from storage
   */
  clear(): void {
    try {
      this.storage.clear();
    } catch (error) {
      console.error('Error clearing storage:', error);
    }
  }

  /**
   * Check if key exists
   */
  has(key: string): boolean {
    return this.storage.getItem(key) !== null;
  }

  /**
   * Get all keys
   */
  keys(): string[] {
    return Object.keys(this.storage);
  }
}

// Create instances
export const localStorage = new StorageService(window.localStorage);
export const sessionStorage = new StorageService(window.sessionStorage);

// Specific storage helpers
export const authStorage = {
  getToken: () => localStorage.get<string>(STORAGE_KEYS.AUTH_TOKEN),
  setToken: (token: string) => localStorage.set(STORAGE_KEYS.AUTH_TOKEN, token),
  removeToken: () => localStorage.remove(STORAGE_KEYS.AUTH_TOKEN),
  
  getRefreshToken: () => localStorage.get<string>(STORAGE_KEYS.REFRESH_TOKEN),
  setRefreshToken: (token: string) => localStorage.set(STORAGE_KEYS.REFRESH_TOKEN, token),
  removeRefreshToken: () => localStorage.remove(STORAGE_KEYS.REFRESH_TOKEN),
  
  clear: () => {
    localStorage.remove(STORAGE_KEYS.AUTH_TOKEN);
    localStorage.remove(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.remove(STORAGE_KEYS.USER);
  },
};

export const cartStorage = {
  getCartId: () => localStorage.get<string>(STORAGE_KEYS.CART_ID),
  setCartId: (id: string) => localStorage.set(STORAGE_KEYS.CART_ID, id),
  removeCartId: () => localStorage.remove(STORAGE_KEYS.CART_ID),
};
