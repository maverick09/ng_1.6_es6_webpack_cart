/**
 * Default Layout Component
 */

import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';

interface DefaultLayoutProps {
  children: ReactNode;
}

export const DefaultLayout: React.FC<DefaultLayoutProps> = ({ children }) => {
  const auth = useAuth();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-blue-600 text-white shadow-lg">
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="text-2xl font-bold">
              Enterprise MFE
            </Link>

            <div className="flex items-center space-x-6">
              <Link to="/products" className="hover:text-blue-200 transition">
                Products
              </Link>
              <Link to="/cart" className="hover:text-blue-200 transition">
                Cart
              </Link>

              {auth.isAuthenticated ? (
                <>
                  <Link to="/orders" className="hover:text-blue-200 transition">
                    Orders
                  </Link>
                  <Link to="/profile" className="hover:text-blue-200 transition">
                    Profile
                  </Link>
                  <button
                    onClick={() => auth.logout()}
                    className="px-4 py-2 bg-blue-700 rounded hover:bg-blue-800 transition"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  className="px-4 py-2 bg-blue-700 rounded hover:bg-blue-800 transition"
                >
                  Login
                </Link>
              )}
            </div>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 mt-auto">
        <div className="container mx-auto px-4 text-center">
          <p>&copy; 2025 Enterprise MFE. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default DefaultLayout;
