/**
 * Authentication Context
 */

import { createContext, useState, useEffect, ReactNode } from 'react';
import type { AuthContextValue, User } from '@enterprise-mfe/shared-types';
import { storage, STORAGE_KEYS } from '@enterprise-mfe/shared-utils';

export const AuthContext = createContext<AuthContextValue | null>(null);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [refreshToken, setRefreshToken] = useState<string | null>(null);

  useEffect(() => {
    // Check for stored authentication on mount
    const storedToken = storage.get<string>(STORAGE_KEYS.AUTH_TOKEN);
    const storedUser = storage.get<User>(STORAGE_KEYS.USER_DATA);
    const storedRefreshToken = storage.get<string>(STORAGE_KEYS.REFRESH_TOKEN);

    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(storedUser);
      setRefreshToken(storedRefreshToken);
      setIsAuthenticated(true);
    }
  }, []);

  const login = async (email: string, password: string): Promise<void> => {
    try {
      // TODO: Replace with actual API call
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        throw new Error('Login failed');
      }

      const data = await response.json();

      // Store authentication data
      storage.set(STORAGE_KEYS.AUTH_TOKEN, data.token);
      storage.set(STORAGE_KEYS.REFRESH_TOKEN, data.refreshToken);
      storage.set(STORAGE_KEYS.USER_DATA, data.user);

      setToken(data.token);
      setRefreshToken(data.refreshToken);
      setUser(data.user);
      setIsAuthenticated(true);
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      // TODO: Replace with actual API call
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear authentication data
      storage.remove(STORAGE_KEYS.AUTH_TOKEN);
      storage.remove(STORAGE_KEYS.REFRESH_TOKEN);
      storage.remove(STORAGE_KEYS.USER_DATA);

      setToken(null);
      setRefreshToken(null);
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  const refreshAuth = async (): Promise<void> => {
    if (!refreshToken) {
      throw new Error('No refresh token available');
    }

    try {
      // TODO: Replace with actual API call
      const response = await fetch('/api/auth/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken }),
      });

      if (!response.ok) {
        throw new Error('Token refresh failed');
      }

      const data = await response.json();

      // Update stored tokens
      storage.set(STORAGE_KEYS.AUTH_TOKEN, data.token);
      storage.set(STORAGE_KEYS.REFRESH_TOKEN, data.refreshToken);

      setToken(data.token);
      setRefreshToken(data.refreshToken);
    } catch (error) {
      console.error('Refresh error:', error);
      await logout();
      throw error;
    }
  };

  const hasRole = (role: string): boolean => {
    return user?.roles?.includes(role) ?? false;
  };

  const hasPermission = (permission: string): boolean => {
    return user?.permissions?.includes(permission) ?? false;
  };

  const value: AuthContextValue = {
    isAuthenticated,
    user,
    token,
    refreshToken,
    login,
    logout,
    refreshAuth,
    hasRole,
    hasPermission,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export default AuthProvider;
