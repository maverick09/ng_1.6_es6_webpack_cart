/**
 * withAuth HOC - Higher Order Component for Authentication
 */

import { ComponentType, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Loading } from '../components/Loading';

interface WithAuthOptions {
  requiredRoles?: string[];
  requiredPermissions?: string[];
  redirectTo?: string;
  fallback?: ComponentType;
}

export function withAuth<P extends object>(
  Component: ComponentType<P>,
  options: WithAuthOptions = {}
): ComponentType<P> {
  const {
    requiredRoles = [],
    requiredPermissions = [],
    redirectTo = '/login',
    fallback: FallbackComponent,
  } = options;

  return function WithAuthComponent(props: P) {
    const navigate = useNavigate();
    const auth = useAuth();

    useEffect(() => {
      // Check if user is authenticated
      if (!auth.isAuthenticated) {
        navigate(redirectTo, { replace: true });
        return;
      }

      // Check roles
      if (requiredRoles.length > 0) {
        const hasRequiredRole = requiredRoles.some((role) =>
          auth.hasRole(role)
        );

        if (!hasRequiredRole) {
          console.warn('User does not have required role');
          navigate('/unauthorized', { replace: true });
          return;
        }
      }

      // Check permissions
      if (requiredPermissions.length > 0) {
        const hasRequiredPermission = requiredPermissions.every(
          (permission) => auth.hasPermission(permission)
        );

        if (!hasRequiredPermission) {
          console.warn('User does not have required permissions');
          navigate('/unauthorized', { replace: true });
          return;
        }
      }
    }, [auth.isAuthenticated, navigate]);

    // Show loading state while checking auth
    if (!auth.isAuthenticated) {
      return FallbackComponent ? (
        <FallbackComponent {...props} />
      ) : (
        <Loading message="Checking authentication..." />
      );
    }

    return <Component {...props} />;
  };
}

export default withAuth;
