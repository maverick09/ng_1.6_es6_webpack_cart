/**
 * Error Boundary Component
 */

import { Component, ReactNode } from 'react';
import type { ErrorProps } from '@enterprise-mfe/shared-types';

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: React.ComponentType<ErrorProps>;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }
  }

  handleRetry = (): void => {
    this.setState({
      hasError: false,
      error: null,
    });
  };

  render(): ReactNode {
    if (this.state.hasError && this.state.error) {
      const FallbackComponent = this.props.fallback || DefaultErrorFallback;
      
      return (
        <FallbackComponent
          error={this.state.error}
          onRetry={this.handleRetry}
        />
      );
    }

    return this.props.children;
  }
}

/**
 * Default Error Fallback Component
 */
const DefaultErrorFallback: React.FC<ErrorProps> = ({
  error,
  onRetry,
  showDetails = false,
  className = '',
}) => {
  const errorMessage = typeof error === 'string' 
    ? error 
    : error.message || 'An unexpected error occurred';

  return (
    <div
      className={`flex flex-col items-center justify-center p-8 bg-red-50 border border-red-200 rounded-lg ${className}`}
      role="alert"
    >
      <div className="text-red-600 text-4xl mb-4">⚠️</div>
      <h2 className="text-xl font-semibold text-red-800 mb-2">
        Something went wrong
      </h2>
      <p className="text-red-600 text-center mb-4 max-w-md">
        {errorMessage}
      </p>

      {showDetails && typeof error !== 'string' && error.stack && (
        <details className="mb-4 w-full max-w-2xl">
          <summary className="cursor-pointer text-sm text-red-700 hover:text-red-900">
            Show error details
          </summary>
          <pre className="mt-2 p-4 bg-red-100 rounded text-xs overflow-auto max-h-64">
            {error.stack}
          </pre>
        </details>
      )}

      {onRetry && (
        <button
          onClick={onRetry}
          className="px-6 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition-colors"
        >
          Try Again
        </button>
      )}
    </div>
  );
};

export default ErrorBoundary;
