/**
 * API Utilities
 */

import type { ApiResponse, ApiError } from '@enterprise-mfe/shared-types';
import { getApiBaseUrl } from '../runtime/runtimeConfig';

export class ApiClient {
  private baseUrl: string;
  private defaultHeaders: HeadersInit;

  constructor(baseUrl?: string) {
    this.baseUrl = baseUrl || getApiBaseUrl();
    this.defaultHeaders = {
      'Content-Type': 'application/json',
    };
  }

  private getAuthToken(): string | null {
    return localStorage.getItem('auth_token');
  }

  private getHeaders(customHeaders?: HeadersInit): HeadersInit {
    const headers = { ...this.defaultHeaders, ...customHeaders };
    const token = this.getAuthToken();

    if (token) {
      return {
        ...headers,
        Authorization: `Bearer ${token}`,
      };
    }

    return headers;
  }

  private async handleResponse<T>(response: Response): Promise<ApiResponse<T>> {
    if (!response.ok) {
      const error: ApiError = {
        message: response.statusText,
        code: 'API_ERROR',
        status: response.status,
      };

      try {
        const errorData = await response.json();
        error.message = errorData.message || error.message;
        error.details = errorData;
      } catch {
        // Unable to parse error response
      }

      throw error;
    }

    const data = await response.json();
    return {
      data,
      status: response.status,
      timestamp: new Date().toISOString(),
    };
  }

  async get<T = any>(
    endpoint: string,
    options?: RequestInit
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      method: 'GET',
      headers: this.getHeaders(options?.headers),
    });

    return this.handleResponse<T>(response);
  }

  async post<T = any>(
    endpoint: string,
    body?: any,
    options?: RequestInit
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      method: 'POST',
      headers: this.getHeaders(options?.headers),
      body: JSON.stringify(body),
    });

    return this.handleResponse<T>(response);
  }

  async put<T = any>(
    endpoint: string,
    body?: any,
    options?: RequestInit
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      method: 'PUT',
      headers: this.getHeaders(options?.headers),
      body: JSON.stringify(body),
    });

    return this.handleResponse<T>(response);
  }

  async patch<T = any>(
    endpoint: string,
    body?: any,
    options?: RequestInit
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      method: 'PATCH',
      headers: this.getHeaders(options?.headers),
      body: JSON.stringify(body),
    });

    return this.handleResponse<T>(response);
  }

  async delete<T = any>(
    endpoint: string,
    options?: RequestInit
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseUrl}${endpoint}`;
    const response = await fetch(url, {
      ...options,
      method: 'DELETE',
      headers: this.getHeaders(options?.headers),
    });

    return this.handleResponse<T>(response);
  }
}

// Default API client instance
export const apiClient = new ApiClient();

// Convenience methods
export const get = <T = any>(endpoint: string, options?: RequestInit) =>
  apiClient.get<T>(endpoint, options);

export const post = <T = any>(endpoint: string, body?: any, options?: RequestInit) =>
  apiClient.post<T>(endpoint, body, options);

export const put = <T = any>(endpoint: string, body?: any, options?: RequestInit) =>
  apiClient.put<T>(endpoint, body, options);

export const patch = <T = any>(endpoint: string, body?: any, options?: RequestInit) =>
  apiClient.patch<T>(endpoint, body, options);

export const del = <T = any>(endpoint: string, options?: RequestInit) =>
  apiClient.delete<T>(endpoint, options);
