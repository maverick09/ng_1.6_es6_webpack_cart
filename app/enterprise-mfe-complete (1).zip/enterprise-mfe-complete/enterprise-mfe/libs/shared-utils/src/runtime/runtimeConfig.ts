/**
 * Runtime Configuration Utilities
 */

import type { RuntimeConfig } from '@enterprise-mfe/shared-types';

/**
 * Get runtime configuration from window.__RUNTIME__
 */
export const getRuntimeConfig = (): RuntimeConfig => {
  if (typeof window === 'undefined') {
    console.warn('Runtime configuration accessed in SSR context');
    return {
      remotes: {},
      environment: 'local',
    };
  }

  if (!window.__RUNTIME__) {
    console.error('Runtime configuration not found! Ensure runtime-config.js is loaded.');
    return {
      remotes: {},
      environment: 'local',
    };
  }

  return window.__RUNTIME__;
};

/**
 * Get remote URL by name
 */
export const getRemoteUrl = (remoteName: string): string => {
  const config = getRuntimeConfig();
  const url = config.remotes[remoteName];

  if (!url) {
    console.error(`Remote "${remoteName}" not found in runtime configuration`);
    return '';
  }

  return url;
};

/**
 * Get remote entry URL
 */
export const getRemoteEntry = (remoteName: string): string => {
  const baseUrl = getRemoteUrl(remoteName);
  return baseUrl ? `${baseUrl}/remoteEntry.js` : '';
};

/**
 * Get current environment
 */
export const getEnvironment = (): RuntimeConfig['environment'] => {
  const config = getRuntimeConfig();
  return config.environment || 'local';
};

/**
 * Check if running in production
 */
export const isProduction = (): boolean => {
  return getEnvironment() === 'production';
};

/**
 * Check if running in development
 */
export const isDevelopment = (): boolean => {
  const env = getEnvironment();
  return env === 'local' || env === 'development';
};

/**
 * Get API base URL
 */
export const getApiBaseUrl = (): string => {
  const config = getRuntimeConfig();
  return config.apiBaseUrl || '';
};

/**
 * Check if feature flag is enabled
 */
export const isFeatureEnabled = (featureName: string): boolean => {
  const config = getRuntimeConfig();
  return config.features?.[featureName] ?? false;
};

/**
 * Get all feature flags
 */
export const getFeatureFlags = (): Record<string, boolean> => {
  const config = getRuntimeConfig();
  return config.features || {};
};

/**
 * Validate runtime configuration
 */
export const validateRuntimeConfig = (): boolean => {
  const config = getRuntimeConfig();
  
  if (!config.remotes || Object.keys(config.remotes).length === 0) {
    console.error('No remotes configured in runtime configuration');
    return false;
  }

  if (!config.environment) {
    console.warn('No environment specified in runtime configuration');
  }

  return true;
};

/**
 * Log runtime configuration (for debugging)
 */
export const logRuntimeConfig = (): void => {
  if (isDevelopment()) {
    const config = getRuntimeConfig();
    console.group('🔧 Runtime Configuration');
    console.log('Environment:', config.environment);
    console.log('Remotes:', config.remotes);
    console.log('API Base URL:', config.apiBaseUrl);
    console.log('Feature Flags:', config.features);
    console.groupEnd();
  }
};
