/**
 * Storage Utilities (localStorage/sessionStorage wrapper)
 */

type StorageType = 'local' | 'session';

class StorageService {
  private getStorage(type: StorageType): Storage {
    return type === 'local' ? localStorage : sessionStorage;
  }

  /**
   * Set item in storage
   */
  set<T>(key: string, value: T, type: StorageType = 'local'): void {
    try {
      const storage = this.getStorage(type);
      const serialized = JSON.stringify(value);
      storage.setItem(key, serialized);
    } catch (error) {
      console.error(`Error setting storage item "${key}":`, error);
    }
  }

  /**
   * Get item from storage
   */
  get<T>(key: string, type: StorageType = 'local'): T | null {
    try {
      const storage = this.getStorage(type);
      const item = storage.getItem(key);
      
      if (item === null) {
        return null;
      }

      return JSON.parse(item) as T;
    } catch (error) {
      console.error(`Error getting storage item "${key}":`, error);
      return null;
    }
  }

  /**
   * Remove item from storage
   */
  remove(key: string, type: StorageType = 'local'): void {
    try {
      const storage = this.getStorage(type);
      storage.removeItem(key);
    } catch (error) {
      console.error(`Error removing storage item "${key}":`, error);
    }
  }

  /**
   * Clear all items from storage
   */
  clear(type: StorageType = 'local'): void {
    try {
      const storage = this.getStorage(type);
      storage.clear();
    } catch (error) {
      console.error('Error clearing storage:', error);
    }
  }

  /**
   * Check if key exists in storage
   */
  has(key: string, type: StorageType = 'local'): boolean {
    try {
      const storage = this.getStorage(type);
      return storage.getItem(key) !== null;
    } catch (error) {
      console.error(`Error checking storage item "${key}":`, error);
      return false;
    }
  }

  /**
   * Get all keys from storage
   */
  keys(type: StorageType = 'local'): string[] {
    try {
      const storage = this.getStorage(type);
      return Object.keys(storage);
    } catch (error) {
      console.error('Error getting storage keys:', error);
      return [];
    }
  }

  /**
   * Get storage size (approximate)
   */
  size(type: StorageType = 'local'): number {
    try {
      const storage = this.getStorage(type);
      return new Blob(Object.values(storage)).size;
    } catch (error) {
      console.error('Error calculating storage size:', error);
      return 0;
    }
  }
}

// Singleton instance
export const storage = new StorageService();

// Storage keys constants
export const STORAGE_KEYS = {
  AUTH_TOKEN: 'auth_token',
  REFRESH_TOKEN: 'refresh_token',
  USER_DATA: 'user_data',
  CART_DATA: 'cart_data',
  THEME_PREFERENCE: 'theme_preference',
  LANGUAGE_PREFERENCE: 'language_preference',
} as const;
