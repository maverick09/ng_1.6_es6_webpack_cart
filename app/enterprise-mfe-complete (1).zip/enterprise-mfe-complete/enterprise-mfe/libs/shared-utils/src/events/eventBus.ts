/**
 * Event Bus for Inter-MFE Communication
 */

import type { MFEEvent, MFEEventHandler } from '@enterprise-mfe/shared-types';

class EventBus {
  private listeners: Map<string, Set<MFEEventHandler>>;

  constructor() {
    this.listeners = new Map();
  }

  /**
   * Subscribe to an event
   */
  on<T = any>(eventType: string, handler: MFEEventHandler<T>): () => void {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, new Set());
    }

    this.listeners.get(eventType)!.add(handler as MFEEventHandler);

    // Return unsubscribe function
    return () => this.off(eventType, handler);
  }

  /**
   * Subscribe to an event (fires only once)
   */
  once<T = any>(eventType: string, handler: MFEEventHandler<T>): () => void {
    const wrappedHandler = (event: MFEEvent<T>) => {
      handler(event);
      this.off(eventType, wrappedHandler);
    };

    return this.on(eventType, wrappedHandler);
  }

  /**
   * Unsubscribe from an event
   */
  off<T = any>(eventType: string, handler: MFEEventHandler<T>): void {
    const handlers = this.listeners.get(eventType);
    if (handlers) {
      handlers.delete(handler as MFEEventHandler);
    }
  }

  /**
   * Emit an event
   */
  emit<T = any>(eventType: string, payload: T, source: string = 'unknown'): void {
    const event: MFEEvent<T> = {
      type: eventType,
      payload,
      source,
      timestamp: new Date().toISOString(),
    };

    const handlers = this.listeners.get(eventType);
    if (handlers) {
      handlers.forEach((handler) => {
        try {
          handler(event);
        } catch (error) {
          console.error(`Error in event handler for "${eventType}":`, error);
        }
      });
    }
  }

  /**
   * Clear all listeners for an event type
   */
  clear(eventType?: string): void {
    if (eventType) {
      this.listeners.delete(eventType);
    } else {
      this.listeners.clear();
    }
  }

  /**
   * Get all event types
   */
  getEventTypes(): string[] {
    return Array.from(this.listeners.keys());
  }

  /**
   * Get listener count for an event
   */
  getListenerCount(eventType: string): number {
    return this.listeners.get(eventType)?.size || 0;
  }
}

// Singleton instance
export const eventBus = new EventBus();

// Common event types
export const MFE_EVENTS = {
  // Cart events
  CART_ITEM_ADDED: 'cart:item:added',
  CART_ITEM_REMOVED: 'cart:item:removed',
  CART_ITEM_UPDATED: 'cart:item:updated',
  CART_CLEARED: 'cart:cleared',
  
  // User events
  USER_LOGGED_IN: 'user:logged:in',
  USER_LOGGED_OUT: 'user:logged:out',
  USER_PROFILE_UPDATED: 'user:profile:updated',
  
  // Product events
  PRODUCT_VIEWED: 'product:viewed',
  PRODUCT_ADDED_TO_WISHLIST: 'product:wishlist:added',
  
  // Navigation events
  NAVIGATION_CHANGED: 'navigation:changed',
  
  // Theme events
  THEME_CHANGED: 'theme:changed',
} as const;

export type MFEEventType = typeof MFE_EVENTS[keyof typeof MFE_EVENTS];
