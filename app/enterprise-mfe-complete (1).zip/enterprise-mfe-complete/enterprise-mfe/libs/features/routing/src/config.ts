import type { MicroFrontendConfig, MicroFrontendRoute } from '@enterprise/shared-types';
import { UserRole } from '@enterprise/shared-types';
import { ROUTES, REMOTES } from '@enterprise/shared-constants';

/**
 * Micro Frontend Configuration
 * Centralized configuration for all micro frontends and their routes
 */
export const microFrontendConfig: MicroFrontendConfig[] = [
  {
    name: REMOTES.PRODUCT,
    displayName: 'Products',
    routes: [
      {
        path: ROUTES.PRODUCTS,
        remote: REMOTES.PRODUCT,
        module: './ProductList',
        exact: true,
        meta: {
          title: 'Products',
          requiresAuth: false,
          showInNav: true,
          icon: '🛍️',
        },
      },
      {
        path: ROUTES.PRODUCT_DETAIL,
        remote: REMOTES.PRODUCT,
        module: './ProductDetail',
        meta: {
          title: 'Product Details',
          requiresAuth: false,
          showInNav: false,
        },
      },
    ],
    errorBoundary: true,
    prefetch: true,
  },
  {
    name: REMOTES.CART,
    displayName: 'Shopping Cart',
    routes: [
      {
        path: ROUTES.CART,
        remote: REMOTES.CART,
        module: './Cart',
        exact: true,
        meta: {
          title: 'Shopping Cart',
          requiresAuth: true,
          showInNav: true,
          icon: '🛒',
        },
      },
      {
        path: ROUTES.CHECKOUT,
        remote: REMOTES.CART,
        module: './Checkout',
        meta: {
          title: 'Checkout',
          requiresAuth: true,
          showInNav: false,
        },
      },
      {
        path: ROUTES.ORDERS,
        remote: REMOTES.CART,
        module: './Orders',
        exact: true,
        meta: {
          title: 'My Orders',
          requiresAuth: true,
          showInNav: true,
          icon: '📦',
        },
      },
      {
        path: ROUTES.ORDER_DETAIL,
        remote: REMOTES.CART,
        module: './OrderDetail',
        meta: {
          title: 'Order Details',
          requiresAuth: true,
          showInNav: false,
        },
      },
    ],
    errorBoundary: true,
    prefetch: false,
  },
  {
    name: REMOTES.USER,
    displayName: 'User Profile',
    routes: [
      {
        path: ROUTES.PROFILE,
        remote: REMOTES.USER,
        module: './Profile',
        exact: true,
        meta: {
          title: 'My Profile',
          requiresAuth: true,
          showInNav: true,
          icon: '👤',
        },
      },
      {
        path: ROUTES.SETTINGS,
        remote: REMOTES.USER,
        module: './Settings',
        meta: {
          title: 'Settings',
          requiresAuth: true,
          roles: [UserRole.USER, UserRole.ADMIN],
          showInNav: true,
          icon: '⚙️',
        },
      },
    ],
    errorBoundary: true,
    prefetch: false,
  },
];

/**
 * Get all routes from all micro frontends
 */
export const getAllRoutes = (): MicroFrontendRoute[] => {
  return microFrontendConfig.flatMap(config => config.routes);
};

/**
 * Get routes by remote name
 */
export const getRoutesByRemote = (remoteName: string): MicroFrontendRoute[] => {
  const config = microFrontendConfig.find(c => c.name === remoteName);
  return config?.routes || [];
};

/**
 * Get route by path
 */
export const getRouteByPath = (path: string): MicroFrontendRoute | undefined => {
  return getAllRoutes().find(route => {
    if (route.exact) {
      return route.path === path;
    }
    return path.startsWith(route.path);
  });
};

/**
 * Get navigation routes (routes that should show in nav)
 */
export const getNavigationRoutes = (): MicroFrontendRoute[] => {
  return getAllRoutes().filter(route => route.meta.showInNav);
};

/**
 * Check if route requires authentication
 */
export const isProtectedRoute = (path: string): boolean => {
  const route = getRouteByPath(path);
  return route?.meta.requiresAuth ?? false;
};

/**
 * Check if user has access to route
 */
export const hasRouteAccess = (path: string, userRole?: UserRole): boolean => {
  const route = getRouteByPath(path);
  
  if (!route) return true;
  if (!route.meta.requiresAuth) return true;
  if (!route.meta.roles || route.meta.roles.length === 0) return true;
  if (!userRole) return false;
  
  return route.meta.roles.includes(userRole);
};
