import { lazy, ComponentType, Suspense } from 'react';
import type { MicroFrontendRoute } from '@enterprise/shared-types';

/**
 * Load a remote component dynamically
 */
export const loadRemoteComponent = (
  remote: string,
  module: string
): ComponentType<any> => {
  return lazy(() => {
    console.log(`📦 Loading remote component: ${remote}/${module}`);
    
    return import(/* @vite-ignore */ `${remote}/${module}`)
      .then((mod) => {
        console.log(`✅ Successfully loaded: ${remote}/${module}`);
        return { default: mod.default };
      })
      .catch((error) => {
        console.error(`❌ Failed to load ${remote}/${module}:`, error);
        
        // Return error component
        return {
          default: () => (
            <div style={{ padding: '20px', textAlign: 'center' }}>
              <h2>Failed to Load Component</h2>
              <p>Remote: {remote}</p>
              <p>Module: {module}</p>
              <p style={{ color: 'red' }}>{error.message}</p>
            </div>
          ),
        };
      });
  });
};

/**
 * Create a component map from routes
 */
export const createComponentMap = (
  routes: MicroFrontendRoute[]
): Record<string, ComponentType<any>> => {
  const componentMap: Record<string, ComponentType<any>> = {};

  routes.forEach((route) => {
    const key = `${route.remote}/${route.module}`;
    if (!componentMap[key]) {
      componentMap[key] = loadRemoteComponent(route.remote, route.module);
    }
  });

  return componentMap;
};

/**
 * Get component for a route
 */
export const getRouteComponent = (
  route: MicroFrontendRoute,
  componentMap: Record<string, ComponentType<any>>
): ComponentType<any> => {
  const key = `${route.remote}/${route.module}`;
  return componentMap[key] || loadRemoteComponent(route.remote, route.module);
};
