/**
 * MFE Configuration Library
 */

export * from './config/microFrontendConfig';
export * from './config/sharedDependencies';
export * from './plugins/runtimePlugin';
