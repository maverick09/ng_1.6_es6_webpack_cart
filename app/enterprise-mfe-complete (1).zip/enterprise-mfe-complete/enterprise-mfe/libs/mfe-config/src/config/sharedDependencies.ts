/**
 * Shared Dependencies Configuration
 * Centralized dependency management for Module Federation
 */

export const sharedDependencies = {
  react: {
    singleton: true,
    requiredVersion: '^18.3.1',
    eager: false,
  },
  'react-dom': {
    singleton: true,
    requiredVersion: '^18.3.1',
    eager: false,
  },
  'react-router-dom': {
    singleton: true,
    requiredVersion: '^6.22.0',
    eager: false,
  },
  '@enterprise-mfe/shared-types': {
    singleton: true,
    eager: false,
  },
  '@enterprise-mfe/shared-ui': {
    singleton: true,
    eager: false,
  },
  '@enterprise-mfe/shared-utils': {
    singleton: true,
    eager: false,
  },
} as const;

export type SharedDependencies = typeof sharedDependencies;
