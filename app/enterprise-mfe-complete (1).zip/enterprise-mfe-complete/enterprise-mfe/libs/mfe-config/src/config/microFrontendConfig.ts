/**
 * Micro Frontend Configuration
 * Centralized configuration for all micro frontends
 */

import type { MicroFrontendConfig } from '@enterprise-mfe/shared-types';

export const microFrontendConfig: MicroFrontendConfig[] = [
  {
    name: 'product',
    displayName: 'Product Catalog',
    description: 'Browse and search products',
    routes: [
      {
        path: '/products',
        title: 'Products',
        remote: 'product',
        module: './ProductList',
        exact: true,
        meta: {
          requiresAuth: false,
          layout: 'default',
        },
      },
      {
        path: '/products/:id',
        title: 'Product Details',
        remote: 'product',
        module: './ProductDetail',
        meta: {
          requiresAuth: false,
          layout: 'default',
        },
      },
      {
        path: '/products/category/:category',
        title: 'Products by Category',
        remote: 'product',
        module: './ProductsByCategory',
        meta: {
          requiresAuth: false,
          layout: 'default',
        },
      },
    ],
    errorBoundary: true,
  },
  {
    name: 'cart',
    displayName: 'Shopping Cart',
    description: 'Manage cart and checkout',
    routes: [
      {
        path: '/cart',
        title: 'Shopping Cart',
        remote: 'cart',
        module: './Cart',
        exact: true,
        meta: {
          requiresAuth: false,
          layout: 'default',
        },
      },
      {
        path: '/checkout',
        title: 'Checkout',
        remote: 'cart',
        module: './Checkout',
        exact: true,
        meta: {
          requiresAuth: true,
          layout: 'minimal',
        },
      },
      {
        path: '/orders',
        title: 'My Orders',
        remote: 'cart',
        module: './OrderHistory',
        exact: true,
        meta: {
          requiresAuth: true,
          layout: 'default',
        },
      },
      {
        path: '/orders/:id',
        title: 'Order Details',
        remote: 'cart',
        module: './OrderDetail',
        meta: {
          requiresAuth: true,
          layout: 'default',
        },
      },
    ],
    errorBoundary: true,
  },
  {
    name: 'user',
    displayName: 'User Account',
    description: 'User profile and settings',
    routes: [
      {
        path: '/profile',
        title: 'My Profile',
        remote: 'user',
        module: './Profile',
        exact: true,
        meta: {
          requiresAuth: true,
          layout: 'default',
        },
      },
      {
        path: '/settings',
        title: 'Account Settings',
        remote: 'user',
        module: './Settings',
        exact: true,
        meta: {
          requiresAuth: true,
          layout: 'default',
        },
      },
      {
        path: '/wishlist',
        title: 'My Wishlist',
        remote: 'user',
        module: './Wishlist',
        exact: true,
        meta: {
          requiresAuth: true,
          layout: 'default',
        },
      },
    ],
    errorBoundary: true,
  },
];

/**
 * Get all routes from all micro frontends
 */
export const getAllRoutes = () => {
  return microFrontendConfig.flatMap((config) => config.routes);
};

/**
 * Get routes for a specific micro frontend
 */
export const getRoutesByMFE = (mfeName: string) => {
  const config = microFrontendConfig.find((c) => c.name === mfeName);
  return config?.routes || [];
};

/**
 * Get route by path
 */
export const getRouteByPath = (path: string) => {
  const allRoutes = getAllRoutes();
  return allRoutes.find((route) => route.path === path);
};

/**
 * Get micro frontend config by name
 */
export const getMFEConfig = (mfeName: string) => {
  return microFrontendConfig.find((c) => c.name === mfeName);
};

/**
 * Get all micro frontend names
 */
export const getAllMFENames = () => {
  return microFrontendConfig.map((c) => c.name);
};
