/**
 * Module Federation Runtime Plugin
 * Overrides remote URLs from window.__RUNTIME__
 */

import type { FederationRuntimePlugin } from '@module-federation/runtime/types';
import { getRemoteUrl, isDevelopment } from '@enterprise-mfe/shared-utils';

export const createRuntimePlugin = (): FederationRuntimePlugin => ({
  name: 'enterprise-runtime-plugin',

  beforeInit(args) {
    if (isDevelopment()) {
      console.log('🔧 [Runtime Plugin] beforeInit', args);
    }
    return args;
  },

  beforeRequest(args) {
    const { id } = args;

    if (!id) {
      return args;
    }

    // Extract remote name from id (e.g., "product/ProductList" -> "product")
    const remoteName = id.split('/')[0];

    // Get runtime URL for this remote
    const runtimeUrl = getRemoteUrl(remoteName);

    if (runtimeUrl) {
      if (isDevelopment()) {
        console.log(`🔄 [Runtime Plugin] Overriding ${remoteName} URL to ${runtimeUrl}`);
      }

      return {
        ...args,
        url: `${runtimeUrl}/remoteEntry.js`,
      };
    }

    if (isDevelopment()) {
      console.warn(`⚠️ [Runtime Plugin] No runtime URL found for remote: ${remoteName}`);
    }

    return args;
  },

  afterResolve(args) {
    if (isDevelopment()) {
      console.log('🔧 [Runtime Plugin] afterResolve', {
        id: args.id,
        remote: args.remote,
      });
    }
    return args;
  },

  onLoad(args) {
    if (isDevelopment()) {
      console.log('✅ [Runtime Plugin] onLoad', args.id);
    }
    return args;
  },

  errorLoadRemote(args) {
    console.error('❌ [Runtime Plugin] Failed to load remote:', {
      id: args.id,
      error: args.error,
      from: args.from,
    });

    // You can implement retry logic here
    // or fallback to a different remote

    return args;
  },

  beforeLoadShare(args) {
    if (isDevelopment()) {
      console.log('🔧 [Runtime Plugin] beforeLoadShare', args);
    }
    return args;
  },
});

// Export singleton instance
export const runtimePlugin = createRuntimePlugin;
