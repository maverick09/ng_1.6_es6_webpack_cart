/**
 * Shell Module Federation Configuration
 */

import { sharedDependencies } from '@enterprise-mfe/mfe-config';

export default {
  name: 'shell',
  
  // Remotes - URLs will be overridden by runtime plugin
  remotes: {
    product: {
      entry: 'http://localhost:3001/remoteEntry.js',
      type: 'module',
    },
    cart: {
      entry: 'http://localhost:3002/remoteEntry.js',
      type: 'module',
    },
    user: {
      entry: 'http://localhost:3003/remoteEntry.js',
      type: 'module',
    },
  },

  // Shared dependencies (centrally managed)
  shared: sharedDependencies,

  // Runtime plugins
  runtimePlugins: ['@enterprise-mfe/mfe-config/plugins/runtimePlugin'],
};
