import type { FederationRuntimePlugin } from '@module-federation/runtime/types';
import { getRemoteUrl } from '@enterprise/shared-utils';

/**
 * Runtime Plugin for Module Federation
 * Overrides remote URLs with runtime configuration
 */
export const runtimePlugin: () => FederationRuntimePlugin = () => ({
  name: 'runtime-url-override-plugin',
  
  /**
   * Before request - Override remote URLs
   */
  beforeRequest(args) {
    const { id } = args;
    
    if (!id) return args;

    // Extract remote name from ID (e.g., "product" from "product/ProductList")
    const remoteName = id.split('/')[0];
    
    if (!remoteName) return args;

    // Get runtime URL for this remote
    const runtimeUrl = getRemoteUrl(remoteName);
    
    if (runtimeUrl) {
      console.log(`🔄 Runtime Plugin: Overriding ${remoteName} URL to ${runtimeUrl}`);
      
      return {
        ...args,
        url: `${runtimeUrl}/remoteEntry.js`,
      };
    }

    return args;
  },

  /**
   * Error handler for remote loading failures
   */
  errorLoadRemote(args) {
    const { id, error, from } = args;
    
    console.error('❌ Runtime Plugin: Failed to load remote');
    console.error(`   Remote ID: ${id}`);
    console.error(`   From: ${from}`);
    console.error(`   Error:`, error);

    // You can implement retry logic here if needed
    // Or send error to monitoring service

    return args;
  },

  /**
   * Before init - Log initialization
   */
  beforeInit(args) {
    console.log('🔧 Runtime Plugin: Module Federation initializing', args);
    return args;
  },

  /**
   * After resolve - Log successful resolution
   */
  afterResolve(args) {
    if (args.pkgNameOrAlias) {
      console.log(`✅ Runtime Plugin: Resolved ${args.pkgNameOrAlias}`);
    }
    return args;
  },
});
