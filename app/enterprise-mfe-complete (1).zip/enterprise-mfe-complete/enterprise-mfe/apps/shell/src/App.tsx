import React, { Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Loading } from './components/Loading';
import { Header } from './components/Header';
import { Home } from './pages/Home';
import { NotFound } from './pages/NotFound';
import { getAllRoutes, createComponentMap } from '@enterprise/feature-routing';
import './App.css';

/**
 * Main Application Component
 */
function App() {
  // Get all routes from configuration
  const routes = getAllRoutes();
  
  // Create component map for all remote modules
  const componentMap = createComponentMap(routes);

  return (
    <BrowserRouter>
      <div className="app">
        <Header />
        
        <main className="app-main">
          <ErrorBoundary>
            <Suspense fallback={<Loading message="Loading application..." />}>
              <Routes>
                {/* Home route */}
                <Route path="/" element={<Home />} />

                {/* Dynamic routes from micro frontends */}
                {routes.map((route) => {
                  const Component = componentMap[`${route.remote}/${route.module}`];

                  return (
                    <Route
                      key={route.path}
                      path={route.path}
                      element={
                        <ErrorBoundary>
                          <Suspense fallback={<Loading message={`Loading ${route.meta.title}...`} />}>
                            <PageWrapper title={route.meta.title}>
                              <Component />
                            </PageWrapper>
                          </Suspense>
                        </ErrorBoundary>
                      }
                    />
                  );
                })}

                {/* 404 Not Found */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </ErrorBoundary>
        </main>

        <footer className="app-footer">
          <p>&copy; 2025 Enterprise MFE Platform. All rights reserved.</p>
        </footer>
      </div>
    </BrowserRouter>
  );
}

/**
 * Page Wrapper Component
 * Sets page title and provides consistent page structure
 */
const PageWrapper: React.FC<{ title: string; children: React.ReactNode }> = ({
  title,
  children,
}) => {
  React.useEffect(() => {
    document.title = `${title} | Enterprise MFE`;
  }, [title]);

  return <div className="page-wrapper">{children}</div>;
};

export default App;
