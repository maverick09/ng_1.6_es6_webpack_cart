/// <reference types="vite/client" />

// Product Remote
declare module 'product/ProductList' {
  const ProductList: React.ComponentType;
  export default ProductList;
}

declare module 'product/ProductDetail' {
  const ProductDetail: React.ComponentType;
  export default ProductDetail;
}

// Cart Remote
declare module 'cart/Cart' {
  const Cart: React.ComponentType;
  export default Cart;
}

declare module 'cart/Checkout' {
  const Checkout: React.ComponentType;
  export default Checkout;
}

declare module 'cart/Orders' {
  const Orders: React.ComponentType;
  export default Orders;
}

declare module 'cart/OrderDetail' {
  const OrderDetail: React.ComponentType;
  export default OrderDetail;
}

// User Remote
declare module 'user/Profile' {
  const Profile: React.ComponentType;
  export default Profile;
}

declare module 'user/Settings' {
  const Settings: React.ComponentType;
  export default Settings;
}
