import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '@enterprise/shared-store';
import { getNavigationRoutes } from '@enterprise/feature-routing';
import './Header.css';

/**
 * Header Component
 * Main navigation header for the application
 */
export const Header: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuthStore();
  const navRoutes = getNavigationRoutes();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-logo">
          <Link to="/">
            <h1>🏢 Enterprise MFE</h1>
          </Link>
        </div>

        <nav className="header-nav">
          {navRoutes.map((route) => {
            // Don't show auth-required routes if not authenticated
            if (route.meta.requiresAuth && !isAuthenticated) {
              return null;
            }

            return (
              <Link
                key={route.path}
                to={route.path}
                className="nav-link"
              >
                {route.meta.icon && <span>{route.meta.icon}</span>}
                {route.meta.title}
              </Link>
            );
          })}
        </nav>

        <div className="header-actions">
          {isAuthenticated && user ? (
            <>
              <span className="user-name">
                👤 {user.firstName} {user.lastName}
              </span>
              <button onClick={handleLogout} className="logout-btn">
                Logout
              </button>
            </>
          ) : (
            <Link to="/login" className="login-btn">
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};
