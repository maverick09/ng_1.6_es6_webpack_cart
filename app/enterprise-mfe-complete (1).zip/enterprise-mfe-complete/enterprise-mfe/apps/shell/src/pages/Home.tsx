import React from 'react';
import { Link } from 'react-router-dom';
import { useAuthStore } from '@enterprise/shared-store';
import { getRuntimeConfig } from '@enterprise/shared-utils';
import './Home.css';

/**
 * Home Page Component
 */
export const Home: React.FC = () => {
  const { isAuthenticated, user } = useAuthStore();
  const config = getRuntimeConfig();

  return (
    <div className="home-container">
      <div className="home-hero">
        <h1>Welcome to Enterprise MFE Platform</h1>
        {isAuthenticated && user ? (
          <p className="welcome-message">
            Hello, {user.firstName}! Ready to shop?
          </p>
        ) : (
          <p>Your modern e-commerce experience</p>
        )}
      </div>

      <div className="home-cards">
        <div className="card">
          <div className="card-icon">🛍️</div>
          <h2>Browse Products</h2>
          <p>Explore our wide selection of products</p>
          <Link to="/products" className="card-button">
            View Products
          </Link>
        </div>

        <div className="card">
          <div className="card-icon">🛒</div>
          <h2>Shopping Cart</h2>
          <p>Manage your cart and proceed to checkout</p>
          <Link to="/cart" className="card-button">
            Go to Cart
          </Link>
        </div>

        <div className="card">
          <div className="card-icon">👤</div>
          <h2>My Profile</h2>
          <p>View and edit your profile information</p>
          <Link to="/profile" className="card-button">
            View Profile
          </Link>
        </div>
      </div>

      <div className="home-info">
        <h3>Platform Information</h3>
        <div className="info-grid">
          <div className="info-item">
            <strong>Environment:</strong> {config.environment}
          </div>
          <div className="info-item">
            <strong>Version:</strong> {config.version}
          </div>
          <div className="info-item">
            <strong>API:</strong> {config.apiBaseUrl}
          </div>
        </div>

        <h4>Loaded Micro Frontends:</h4>
        <ul className="remote-list">
          {Object.entries(config.remotes).map(([name, url]) => (
            <li key={name}>
              <strong>{name}:</strong> {url}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
