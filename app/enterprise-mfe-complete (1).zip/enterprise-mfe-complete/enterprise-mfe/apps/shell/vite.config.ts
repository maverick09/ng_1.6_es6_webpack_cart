import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { federation } from '@module-federation/vite';
import moduleFederationConfig from './module-federation.config';
import path from 'path';

export default defineConfig({
  plugins: [
    react(),
    federation(moduleFederationConfig),
  ],

  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@enterprise/shared-types': path.resolve(__dirname, '../../libs/shared/types/src'),
      '@enterprise/shared-utils': path.resolve(__dirname, '../../libs/shared/utils/src'),
      '@enterprise/shared-constants': path.resolve(__dirname, '../../libs/shared/constants/src'),
      '@enterprise/shared-api': path.resolve(__dirname, '../../libs/shared/api/src'),
      '@enterprise/shared-store': path.resolve(__dirname, '../../libs/shared/store/src'),
      '@enterprise/feature-routing': path.resolve(__dirname, '../../libs/features/routing/src'),
    },
  },

  build: {
    target: 'esnext',
    minify: false,
    cssCodeSplit: false,
    rollupOptions: {
      output: {
        manualChunks: undefined,
      },
    },
  },

  server: {
    port: 3000,
    strictPort: true,
    cors: true,
    open: true,
  },

  preview: {
    port: 3000,
    strictPort: true,
  },
});
