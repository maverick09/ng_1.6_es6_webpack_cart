import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { productsApi } from '@enterprise/shared-api';
import type { Product } from '@enterprise/shared-types';
import { formatCurrency } from '@enterprise/shared-utils';
import './ProductList.css';

/**
 * Product List Component
 * Displays a list of products
 */
const ProductList: React.FC = () => {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      setLoading(true);
      // Mock data for demonstration
      const mockProducts: Product[] = [
        {
          id: '1',
          name: 'Wireless Headphones',
          description: 'Premium noise-canceling headphones',
          price: 299.99,
          currency: 'USD',
          imageUrl: 'https://via.placeholder.com/300x200?text=Headphones',
          category: 'Electronics',
          stock: 15,
          rating: 4.5,
          reviews: 120,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: '2',
          name: 'Smart Watch',
          description: 'Fitness tracking and notifications',
          price: 399.99,
          currency: 'USD',
          imageUrl: 'https://via.placeholder.com/300x200?text=Smart+Watch',
          category: 'Electronics',
          stock: 25,
          rating: 4.7,
          reviews: 89,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: '3',
          name: 'Laptop Backpack',
          description: 'Durable and stylish laptop backpack',
          price: 79.99,
          currency: 'USD',
          imageUrl: 'https://via.placeholder.com/300x200?text=Backpack',
          category: 'Accessories',
          stock: 40,
          rating: 4.3,
          reviews: 56,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ];
      
      setProducts(mockProducts);
      setLoading(false);
    } catch (err: any) {
      setError(err.message || 'Failed to load products');
      setLoading(false);
    }
  };

  const handleProductClick = (id: string) => {
    navigate(`/products/${id}`);
  };

  if (loading) {
    return <div className="products-loading">Loading products...</div>;
  }

  if (error) {
    return <div className="products-error">Error: {error}</div>;
  }

  return (
    <div className="products-container">
      <div className="products-header">
        <h1>Our Products</h1>
        <p>Discover our amazing collection</p>
      </div>

      <div className="products-grid">
        {products.map((product) => (
          <div
            key={product.id}
            className="product-card"
            onClick={() => handleProductClick(product.id)}
          >
            <div className="product-image">
              <img src={product.imageUrl} alt={product.name} />
              {product.stock < 10 && (
                <span className="product-badge">Low Stock</span>
              )}
            </div>
            <div className="product-content">
              <span className="product-category">{product.category}</span>
              <h3 className="product-name">{product.name}</h3>
              <p className="product-description">{product.description}</p>
              <div className="product-footer">
                <span className="product-price">
                  {formatCurrency(product.price, product.currency)}
                </span>
                <div className="product-rating">
                  ⭐ {product.rating} ({product.reviews})
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ProductList;
