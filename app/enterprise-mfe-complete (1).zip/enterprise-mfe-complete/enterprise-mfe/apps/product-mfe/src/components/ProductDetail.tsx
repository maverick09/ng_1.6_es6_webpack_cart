import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { formatCurrency } from '@enterprise/shared-utils';
import './ProductDetail.css';

/**
 * Product Detail Component
 * Displays detailed information about a single product
 */
const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  // Mock product data
  const product = {
    id: id || '1',
    name: 'Wireless Headphones',
    description: 'Premium noise-canceling headphones with exceptional sound quality',
    price: 299.99,
    currency: 'USD',
    imageUrl: 'https://via.placeholder.com/600x400?text=Headphones',
    category: 'Electronics',
    stock: 15,
    rating: 4.5,
    reviews: 120,
    features: [
      'Active Noise Cancellation',
      '30-hour battery life',
      'Wireless Bluetooth 5.0',
      'Premium sound quality',
      'Comfortable design',
    ],
  };

  const handleAddToCart = () => {
    alert(`Added ${product.name} to cart!`);
    // In real app: useCartStore().addItem(product.id, 1);
  };

  return (
    <div className="product-detail-container">
      <button className="back-button" onClick={() => navigate('/products')}>
        ← Back to Products
      </button>

      <div className="product-detail-content">
        <div className="product-detail-image">
          <img src={product.imageUrl} alt={product.name} />
        </div>

        <div className="product-detail-info">
          <span className="product-detail-category">{product.category}</span>
          <h1 className="product-detail-name">{product.name}</h1>
          
          <div className="product-detail-rating">
            ⭐ {product.rating} ({product.reviews} reviews)
          </div>

          <p className="product-detail-description">{product.description}</p>

          <div className="product-detail-features">
            <h3>Key Features:</h3>
            <ul>
              {product.features.map((feature, index) => (
                <li key={index}>{feature}</li>
              ))}
            </ul>
          </div>

          <div className="product-detail-footer">
            <div className="product-detail-price">
              {formatCurrency(product.price, product.currency)}
            </div>
            <button className="add-to-cart-button" onClick={handleAddToCart}>
              Add to Cart
            </button>
          </div>

          <div className="product-detail-stock">
            {product.stock > 10 ? (
              <span className="in-stock">✓ In Stock</span>
            ) : (
              <span className="low-stock">⚠️ Only {product.stock} left</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
