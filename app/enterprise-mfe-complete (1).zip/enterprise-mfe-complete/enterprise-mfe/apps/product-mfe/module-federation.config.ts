export default {
  name: 'product',
  filename: 'remoteEntry.js',

  // Exposed modules
  exposes: {
    './ProductList': './src/components/ProductList.tsx',
    './ProductDetail': './src/components/ProductDetail.tsx',
  },

  // Shared dependencies - Must match shell versions
  shared: {
    react: {
      singleton: true,
      requiredVersion: '^18.3.1',
    },
    'react-dom': {
      singleton: true,
      requiredVersion: '^18.3.1',
    },
    'react-router-dom': {
      singleton: true,
      requiredVersion: '^6.22.0',
    },
    'zustand': {
      singleton: true,
      requiredVersion: '^4.5.0',
    },
    'axios': {
      singleton: true,
      requiredVersion: '^1.6.7',
    },
  },
};
