#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env.local') });

const environment = process.env.NODE_ENV || 'development';
const envFile = environment === 'production' ? '.env.production' : '.env.local';

console.log(`🔧 Generating runtime config for: ${environment}`);
console.log(`📄 Using env file: ${envFile}`);

// Read environment variables
const config = {
  environment,
  apiBaseUrl: process.env.VITE_API_BASE_URL || 'http://localhost:4000',
  remotes: {
    product: process.env.VITE_REMOTE_PRODUCT_URL || 'http://localhost:3001',
    cart: process.env.VITE_REMOTE_CART_URL || 'http://localhost:3002',
    user: process.env.VITE_REMOTE_USER_URL || 'http://localhost:3003',
  },
  features: {
    enableAnalytics: process.env.VITE_ENABLE_ANALYTICS === 'true',
    enableErrorReporting: process.env.VITE_ENABLE_ERROR_REPORTING === 'true',
  },
  version: process.env.npm_package_version || '1.0.0',
};

// Generate the runtime config file
const configContent = `// Auto-generated runtime configuration - DO NOT EDIT MANUALLY
// Generated at: ${new Date().toISOString()}
// Environment: ${environment}

window.__RUNTIME__ = ${JSON.stringify(config, null, 2)};

console.log('✅ Runtime configuration loaded:', window.__RUNTIME__);
`;

// Ensure public directory exists
const shellPublicDir = path.join(__dirname, '../apps/shell/public');
if (!fs.existsSync(shellPublicDir)) {
  fs.mkdirSync(shellPublicDir, { recursive: true });
}

// Write to public directory
const outputPath = path.join(shellPublicDir, 'runtime-config.js');
fs.writeFileSync(outputPath, configContent, 'utf-8');

console.log('✅ Runtime config generated successfully!');
console.log(`📍 Location: ${outputPath}`);
console.log('📦 Configuration:', JSON.stringify(config, null, 2));
