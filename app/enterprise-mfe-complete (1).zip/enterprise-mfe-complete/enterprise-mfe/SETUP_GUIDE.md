# Enterprise Micro Frontend Application - Complete Setup Guide

## 🏗️ Architecture Overview

This is a production-ready, enterprise-grade micro frontend application using Module Federation with **runtime URL configuration**.

### Key Features
- ✅ **No manual `init()` or `loadRemote()` calls** - Uses standard React imports
- ✅ **Runtime URL override** via `window.__RUNTIME__`
- ✅ **Environment-specific configuration** (.env files)
- ✅ **Centralized dependency management** in shell
- ✅ **Type-safe remote imports**
- ✅ **Clean architecture** with shared libraries
- ✅ **Authentication & Authorization** HOCs
- ✅ **Event bus** for inter-MFE communication

---

## 📁 Project Structure

```
enterprise-mfe/
├── apps/
│   ├── shell/                          # Host Application (Port 3000)
│   │   ├── public/
│   │   │   └── runtime-config.js       # Generated runtime configuration
│   │   ├── src/
│   │   │   ├── components/
│   │   │   ├── routes/
│   │   │   ├── App.tsx
│   │   │   ├── main.tsx
│   │   │   └── bootstrap.tsx
│   │   ├── .env.local
│   │   ├── .env.production
│   │   ├── index.html
│   │   ├── module-federation.config.ts
│   │   ├── vite.config.ts
│   │   ├── tsconfig.json
│   │   └── project.json
│   │
│   ├── product/                        # Product MFE (Port 3001)
│   │   ├── src/
│   │   │   ├── components/
│   │   │   │   ├── ProductList.tsx
│   │   │   │   ├── ProductDetail.tsx
│   │   │   │   └── ProductsByCategory.tsx
│   │   │   └── main.tsx
│   │   ├── module-federation.config.ts
│   │   └── vite.config.ts
│   │
│   ├── cart/                           # Cart MFE (Port 3002)
│   │   ├── src/
│   │   │   ├── components/
│   │   │   │   ├── Cart.tsx
│   │   │   │   ├── Checkout.tsx
│   │   │   │   ├── OrderHistory.tsx
│   │   │   │   └── OrderDetail.tsx
│   │   │   └── main.tsx
│   │   ├── module-federation.config.ts
│   │   └── vite.config.ts
│   │
│   └── user/                           # User MFE (Port 3003)
│       ├── src/
│       │   ├── components/
│       │   │   ├── Profile.tsx
│       │   │   ├── Settings.tsx
│       │   │   └── Wishlist.tsx
│       │   └── main.tsx
│       ├── module-federation.config.ts
│       └── vite.config.ts
│
├── libs/
│   ├── shared-types/                   # Shared TypeScript Types
│   │   └── src/
│   │       └── index.ts
│   │
│   ├── shared-utils/                   # Shared Utilities
│   │   └── src/
│   │       ├── runtime/
│   │       │   └── runtimeConfig.ts
│   │       ├── api/
│   │       │   └── apiClient.ts
│   │       ├── events/
│   │       │   └── eventBus.ts
│   │       ├── storage/
│   │       │   └── storage.ts
│   │       └── index.ts
│   │
│   ├── shared-ui/                      # Shared UI Components
│   │   └── src/
│   │       ├── components/
│   │       │   ├── Loading.tsx
│   │       │   └── ErrorBoundary.tsx
│   │       ├── layouts/
│   │       │   └── DefaultLayout.tsx
│   │       ├── hoc/
│   │       │   └── withAuth.tsx
│   │       ├── hooks/
│   │       │   └── useAuth.ts
│   │       ├── contexts/
│   │       │   └── AuthContext.tsx
│   │       └── index.ts
│   │
│   └── mfe-config/                     # MFE Configuration
│       └── src/
│           ├── config/
│           │   ├── microFrontendConfig.ts
│           │   └── sharedDependencies.ts
│           ├── plugins/
│           │   └── runtimePlugin.ts
│           └── index.ts
│
├── tools/
│   └── scripts/
│       └── generate-runtime-config.js  # Runtime config generator
│
├── package.json
├── nx.json
├── tsconfig.base.json
└── README.md
```

---

## 🚀 Getting Started

### 1. Install Dependencies

```bash
npm install
```

### 2. Generate Runtime Configuration

```bash
npm run generate:config
```

This reads environment variables and generates `apps/shell/public/runtime-config.js`

### 3. Start All Applications

```bash
# Start all apps in parallel
npm run start:all

# Or start individually
npm run dev:shell      # Port 3000
npm run dev:product    # Port 3001
npm run dev:cart       # Port 3002
npm run dev:user       # Port 3003
```

### 4. Access the Application

Open http://localhost:3000

---

## 🔧 How Runtime Configuration Works

### 1. Environment Variables (.env.local)

```env
VITE_REMOTE_PRODUCT_URL=http://localhost:3001
VITE_REMOTE_CART_URL=http://localhost:3002
VITE_REMOTE_USER_URL=http://localhost:3003
VITE_ENVIRONMENT=local
```

### 2. Generate Script Creates runtime-config.js

```javascript
window.__RUNTIME__ = {
  remotes: {
    product: "http://localhost:3001",
    cart: "http://localhost:3002",
    user: "http://localhost:3003"
  },
  environment: "local"
};
```

### 3. Runtime Plugin Overrides URLs

```typescript
// In libs/mfe-config/src/plugins/runtimePlugin.ts
beforeRequest(args) {
  const remoteName = args.id.split('/')[0];
  const runtimeUrl = window.__RUNTIME__.remotes[remoteName];
  
  return {
    ...args,
    url: `${runtimeUrl}/remoteEntry.js`,
  };
}
```

### 4. Use Normal React Imports (No manual loadRemote!)

```typescript
// In shell App.tsx
import ProductList from 'product/ProductList';
import Cart from 'cart/Cart';
import Profile from 'user/Profile';

// Just use them like normal components!
<Route path="/products" element={<ProductList />} />
<Route path="/cart" element={<Cart />} />
<Route path="/profile" element={<Profile />} />
```

---

## 🎯 Key Benefits

### ✅ No Init/LoadRemote Complexity
```typescript
// ❌ OLD WAY - Complex and error-prone
init({ name: 'shell', remotes: [...] });
const Component = await loadRemote('product/Module');

// ✅ NEW WAY - Simple React imports
import ProductList from 'product/ProductList';
```

### ✅ No "createInstance" Errors
- Build-time Module Federation setup handles initialization
- Runtime plugin only overrides URLs
- No timing issues or initialization races

### ✅ Type-Safe Imports
```typescript
// TypeScript knows about remote modules
declare module 'product/ProductList' {
  const ProductList: React.ComponentType;
  export default ProductList;
}
```

### ✅ Hot Module Replacement Works
- Standard Vite HMR
- No special handling needed
- Development experience identical to non-federated apps

---

## 🔐 Authentication & Authorization

### Using withAuth HOC

```typescript
import { withAuth } from '@enterprise-mfe/shared-ui';

// Protect a component
const ProtectedComponent = withAuth(MyComponent, {
  requiredRoles: ['admin'],
  requiredPermissions: ['read:users'],
  redirectTo: '/login'
});
```

### Using useAuth Hook

```typescript
import { useAuth } from '@enterprise-mfe/shared-ui';

function MyComponent() {
  const auth = useAuth();
  
  if (!auth.isAuthenticated) {
    return <div>Please login</div>;
  }
  
  return <div>Welcome {auth.user?.firstName}!</div>;
}
```

---

## 📡 Inter-MFE Communication

### Using Event Bus

```typescript
import { eventBus, MFE_EVENTS } from '@enterprise-mfe/shared-utils';

// In Cart MFE - Emit event
eventBus.emit(MFE_EVENTS.CART_ITEM_ADDED, { 
  productId: '123',
  quantity: 1 
}, 'cart');

// In another MFE - Listen for event
eventBus.on(MFE_EVENTS.CART_ITEM_ADDED, (event) => {
  console.log('Item added:', event.payload);
  // Update cart count in header
});
```

---

## 📦 Shared Libraries

### @enterprise-mfe/shared-types
Common TypeScript types used across all MFEs

### @enterprise-mfe/shared-utils
- Runtime configuration helpers
- API client
- Event bus
- Storage utilities

### @enterprise-mfe/shared-ui
- Common UI components (Loading, ErrorBoundary)
- Layouts (DefaultLayout, MinimalLayout)
- HOCs (withAuth)
- Hooks (useAuth)
- Contexts (AuthContext)

### @enterprise-mfe/mfe-config
- Centralized route configuration
- Shared dependencies configuration
- Runtime plugin

---

## 🌍 Environment Configuration

### Local Development
```bash
# .env.local
VITE_REMOTE_PRODUCT_URL=http://localhost:3001
VITE_REMOTE_CART_URL=http://localhost:3002
VITE_REMOTE_USER_URL=http://localhost:3003
```

### Production
```bash
# .env.production
VITE_REMOTE_PRODUCT_URL=https://product.yourdomain.com
VITE_REMOTE_CART_URL=https://cart.yourdomain.com
VITE_REMOTE_USER_URL=https://user.yourdomain.com
```

### Build for Production
```bash
npm run build:all
```

This automatically uses `.env.production` values.

---

## 🎨 Adding a New Micro Frontend

1. **Create the app directory**
```bash
mkdir -p apps/my-new-mfe/src/components
```

2. **Add to environment variables**
```bash
# .env.local
VITE_REMOTE_MY_NEW_MFE_URL=http://localhost:3004
```

3. **Update microFrontendConfig.ts**
```typescript
{
  name: 'myNewMfe',
  routes: [
    {
      path: '/my-feature',
      title: 'My Feature',
      remote: 'myNewMfe',
      module: './MyFeature',
    }
  ]
}
```

4. **Add remote to shell module-federation.config.ts**
```typescript
remotes: {
  myNewMfe: {
    entry: 'http://localhost:3004/remoteEntry.js',
    type: 'module',
  }
}
```

5. **Create remote type declaration**
```typescript
declare module 'myNewMfe/MyFeature' {
  const MyFeature: React.ComponentType;
  export default MyFeature;
}
```

---

## 🐛 Troubleshooting

### Runtime config not loading
- Ensure `runtime-config.js` is in `apps/shell/public/`
- Run `npm run generate:config`
- Check browser console for config loading message

### Remote not loading
- Verify remote app is running on correct port
- Check browser network tab for 404s
- Verify module name in `exposes` matches import

### Type errors on remote imports
- Add type declarations in `src/types/remotes.d.ts`
- Restart TypeScript server

### Shared dependencies not working
- Ensure `sharedDependencies` is identical in all configs
- Check singleton settings
- Clear node_modules and reinstall

---

## 📚 Additional Resources

- [Module Federation Docs](https://module-federation.io/)
- [Vite Plugin Docs](https://github.com/module-federation/vite)
- [NX Docs](https://nx.dev/)

---

## 📄 License

MIT
