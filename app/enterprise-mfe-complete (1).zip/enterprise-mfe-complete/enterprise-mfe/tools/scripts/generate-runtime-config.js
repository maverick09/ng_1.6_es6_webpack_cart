#!/usr/bin/env node

/**
 * Generate Runtime Configuration
 * This script generates runtime-config.js from environment variables
 */

const fs = require('fs');
const path = require('path');

// Load environment variables
const environment = process.env.VITE_ENVIRONMENT || process.env.NODE_ENV || 'local';

const config = {
  remotes: {
    product: process.env.VITE_REMOTE_PRODUCT_URL || 'http://localhost:3001',
    cart: process.env.VITE_REMOTE_CART_URL || 'http://localhost:3002',
    user: process.env.VITE_REMOTE_USER_URL || 'http://localhost:3003',
  },
  environment,
  apiBaseUrl: process.env.VITE_API_BASE_URL || 'http://localhost:4000',
  features: {
    enableNewCheckout: process.env.VITE_FEATURE_NEW_CHECKOUT === 'true',
    enableWishlist: process.env.VITE_FEATURE_WISHLIST === 'true',
    enableRecommendations: process.env.VITE_FEATURE_RECOMMENDATIONS === 'true',
  },
};

// Generate the runtime config file content
const configContent = `
/**
 * Runtime Configuration
 * Auto-generated on ${new Date().toISOString()}
 * DO NOT EDIT MANUALLY
 */
window.__RUNTIME__ = ${JSON.stringify(config, null, 2)};

console.log('✅ Runtime configuration loaded for environment: ${environment}');
`;

// Determine output path
const outputDir = path.join(__dirname, '../../apps/shell/public');
const outputPath = path.join(outputDir, 'runtime-config.js');

// Ensure output directory exists
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Write the file
try {
  fs.writeFileSync(outputPath, configContent, 'utf-8');
  
  console.log('✅ Runtime configuration generated successfully!');
  console.log(`📁 Output: ${outputPath}`);
  console.log('\n📋 Configuration:');
  console.log(JSON.stringify(config, null, 2));
  
} catch (error) {
  console.error('❌ Failed to generate runtime configuration:', error);
  process.exit(1);
}
