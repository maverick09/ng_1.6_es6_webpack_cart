# 🎯 Quick Reference Guide - Enterprise MFE

## The KEY Difference: No More init() or loadRemote()!

### ❌ OLD WAY (What You Were Doing Before)
```typescript
// Had to manually initialize
import { init } from '@module-federation/runtime';
init({
  name: 'shell',
  remotes: [...]
});

// Had to manually load components
import { loadRemote } from '@module-federation/runtime';
const Component = await loadRemote('product/Module');

// Issues:
// - "createInstance first" errors  
// - Timing/initialization problems
// - Complex async code
```

### ✅ NEW WAY (This Solution)
```typescript
// Just import like normal!
import ProductList from 'product/ProductList';

// Use like any React component
<Route path="/products" element={<ProductList />} />

// Benefits:
// ✅ No initialization
// ✅ No manual loading
// ✅ No timing errors
// ✅ Works like standard React
```

---

## How Runtime URL Override Works

### 1. Environment Variables (.env.local)
```env
VITE_REMOTE_PRODUCT_URL=http://localhost:3001
VITE_REMOTE_CART_URL=http://localhost:3002
```

### 2. Generate Script Creates runtime-config.js
```bash
npm run generate:config
```

Creates:
```javascript
window.__RUNTIME__ = {
  remotes: {
    product: "http://localhost:3001",
    cart: "http://localhost:3002"
  }
};
```

### 3. Runtime Plugin Intercepts Requests
```typescript
// In libs/mfe-config/src/plugins/runtimePlugin.ts
beforeRequest(args) {
  const remoteName = args.id.split('/')[0]; // 'product'
  const runtimeUrl = window.__RUNTIME__.remotes[remoteName];
  
  return {
    ...args,
    url: `${runtimeUrl}/remoteEntry.js`, // Override URL!
  };
}
```

### 4. Module Federation Loads From Correct URL
```typescript
// This import:
import ProductList from 'product/ProductList';

// Gets intercepted and loads from:
// http://localhost:3001/remoteEntry.js (local)
// OR
// https://product.yourdomain.com/remoteEntry.js (production)
```

---

## Project Structure at a Glance

```
enterprise-mfe/
│
├── apps/
│   ├── shell/               # Host (3000)
│   │   ├── .env.local       # Local URLs
│   │   ├── .env.production  # Production URLs  
│   │   └── module-federation.config.ts
│   │
│   ├── product/             # Remote (3001)
│   │   ├── module-federation.config.ts
│   │   └── exposes: './ProductList'
│   │
│   ├── cart/                # Remote (3002)
│   └── user/                # Remote (3003)
│
├── libs/
│   ├── shared-types/        # TypeScript types
│   ├── shared-utils/        # Runtime config helpers
│   ├── shared-ui/           # Components, layouts, HOCs
│   └── mfe-config/          # Routes + runtime plugin
│
└── tools/scripts/
    └── generate-runtime-config.js
```

---

## Essential Commands

```bash
# Setup
npm install
npm run generate:config

# Development
npm run start:all              # All apps
npm run dev:shell              # Just shell
npm run dev:product            # Just product

# Production
npm run build:all
npm run preview:shell
```

---

## Common Tasks

### Change Environment URLs
1. Edit `.env.local` or `.env.production`
2. Run `npm run generate:config`
3. Restart apps

### Add New Remote
1. Create app directory
2. Add URL to `.env.local`
3. Update `microFrontendConfig.ts`
4. Add to shell's `module-federation.config.ts`
5. Create type declaration
6. Run `npm run generate:config`

### Debug Runtime Config
```typescript
// In browser console:
console.log(window.__RUNTIME__);

// In code:
import { getRuntimeConfig } from '@enterprise-mfe/shared-utils';
console.log(getRuntimeConfig());
```

---

## File Checklist for Each Remote

### Required Files in Remote (e.g., product)

**`module-federation.config.ts`**
```typescript
export default {
  name: 'product',
  filename: 'remoteEntry.js',
  exposes: {
    './ProductList': './src/components/ProductList.tsx',
  },
  shared: sharedDependencies,
};
```

**`vite.config.ts`**
```typescript
import { federation } from '@module-federation/vite';
import config from './module-federation.config';

export default defineConfig({
  plugins: [react(), federation(config)],
  server: { port: 3001 },
});
```

**`src/components/ProductList.tsx`**
```typescript
export default function ProductList() {
  return <div>Product List</div>;
}
```

---

## Type Declarations Template

**`apps/shell/src/types/remotes.d.ts`**
```typescript
declare module 'product/ProductList' {
  const ProductList: React.ComponentType;
  export default ProductList;
}

declare module 'cart/Cart' {
  const Cart: React.ComponentType;
  export default Cart;
}

// Add one for each exposed module
```

---

## Error Solutions

### "Cannot find module 'product/ProductList'"
1. Check remote is running
2. Check `exposes` in remote config
3. Check type declaration exists
4. Check network tab for 404s

### "window.__RUNTIME__ is undefined"
1. Run `npm run generate:config`
2. Check `public/runtime-config.js` exists
3. Check `<script src="/runtime-config.js"></script>` in HTML

### Multiple React instances
1. Ensure all configs have `singleton: true` for React
2. All remotes must use same shared config
3. Clear node_modules and reinstall

---

## Key Files to Remember

### Must Generate Before Running
```
apps/shell/public/runtime-config.js
```

### Central Configuration
```
libs/mfe-config/src/config/microFrontendConfig.ts
libs/mfe-config/src/config/sharedDependencies.ts
libs/mfe-config/src/plugins/runtimePlugin.ts
```

### Environment Config
```
apps/shell/.env.local
apps/shell/.env.production
```

---

## Testing Checklist

- [ ] Runtime config loads (`window.__RUNTIME__` defined)
- [ ] All remotes are running
- [ ] Can navigate between routes
- [ ] Remote components load without errors
- [ ] Shared state works (cart count, auth)
- [ ] Hot reload works in development
- [ ] Production build works
- [ ] Environment switching works

---

## Pro Tips

1. **Always run `generate:config` first** - Before starting any app
2. **Check browser console** - Runtime plugin logs all URL overrides
3. **Use consistent ports** - Defined in each app's vite.config.ts
4. **Type everything** - Add declarations for all remote modules
5. **Test in production mode** - Run preview builds before deploying

---

## Why This Approach is Stable

1. **Build-time Module Federation** handles initialization
2. **Runtime plugin** only overrides URLs
3. **Standard React patterns** - no custom APIs
4. **Predictable loading** - imports work like normal
5. **No race conditions** - no manual async initialization

---

This solution gives you **all the benefits of Module Federation** with **none of the initialization complexity**.
