# Enterprise Micro Frontend Platform 🚀

A production-ready, enterprise-grade micro frontend architecture using React 18, Vite, Module Federation, and NX.

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Features](#features)
- [Getting Started](#getting-started)
- [Project Structure](#project-structure)
- [Configuration](#configuration)
- [Development](#development)
- [Deployment](#deployment)
- [Best Practices](#best-practices)

---

## 🎯 Overview

This is a **complete, production-ready** micro frontend platform that demonstrates:

✅ **Runtime URL Configuration** - No rebuild needed for environment changes  
✅ **Clean Separation of Concerns** - Shared libraries, features, and apps  
✅ **Type-Safe** - Full TypeScript support across all modules  
✅ **Centralized Dependency Management** - Shell controls all shared versions  
✅ **Event-Driven Communication** - Cross-MFE communication via event bus  
✅ **Global State Management** - Zustand stores shared across MFEs  
✅ **Enterprise-Grade** - Error boundaries, loading states, authentication

---

## 🏗️ Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Shell App (Port 3000)                 │
│  - Header/Navigation                                         │
│  - Runtime Plugin (URL Override)                             │
│  - Route Management                                          │
│  - Shared State (Auth, Cart)                                 │
└─────────────────┬───────────────────────────────────────────┘
                  │
        ┌─────────┼─────────┐
        │         │         │
   ┌────▼───┐ ┌──▼────┐ ┌─▼─────┐
   │Product │ │ Cart  │ │ User  │
   │  MFE   │ │  MFE  │ │  MFE  │
   │ (3001) │ │(3002) │ │(3003) │
   └────────┘ └───────┘ └───────┘
```

### Shared Libraries

```
libs/
├── shared/
│   ├── types/          # TypeScript interfaces & types
│   ├── constants/      # App-wide constants
│   ├── utils/          # Helper functions & utilities
│   ├── api/            # API client & services
│   └── store/          # Zustand stores & event bus
└── features/
    └── routing/        # Route configuration & loader
```

---

## ✨ Features

### 🔧 Runtime Configuration

- **No Rebuild Required** - Change MFE URLs without rebuilding
- **Environment-Specific** - `.env.local` for dev, `.env.production` for prod
- **Generated Config** - `runtime-config.js` auto-generated from env vars

### 🎨 Shell Application

- **Centralized Navigation** - Header with dynamic nav links
- **Route Management** - Config-driven routing from `microFrontendConfig`
- **Error Boundaries** - Graceful error handling for each MFE
- **Loading States** - Beautiful loading indicators
- **Authentication** - Global auth state via Zustand

### 📦 Micro Frontends

- **Isolated** - Each MFE runs independently
- **Exposed Modules** - Clean module exposure via Module Federation
- **Shared Dependencies** - React, React-DOM, Router shared as singletons
- **Type-Safe** - TypeScript declarations for remote modules

### 🔄 State Management

- **Zustand Stores** - Lightweight, performant state management
- **Event Bus** - Cross-MFE communication without coupling
- **Persistent Storage** - LocalStorage wrapper with type safety

---

## 🚀 Getting Started

### Prerequisites

```bash
node >= 18.0.0
npm >= 9.0.0
```

### Installation

```bash
# 1. Clone the repository
git clone <repository-url>
cd enterprise-mfe

# 2. Install dependencies
npm install

# 3. Generate runtime configuration
npm run generate:config

# 4. Start all applications
npm run dev
```

This will start:
- **Shell** on `http://localhost:3000`
- **Product MFE** on `http://localhost:3001`
- **Cart MFE** on `http://localhost:3002`
- **User MFE** on `http://localhost:3003`

### Quick Start (Individual Apps)

```bash
# Start only shell
npm run dev:shell

# Start only product MFE
npm run dev:product

# Start only cart MFE
npm run dev:cart

# Start only user MFE
npm run dev:user
```

---

## 📁 Project Structure

```
enterprise-mfe/
├── apps/
│   ├── shell/                          # Shell Application (Host)
│   │   ├── public/
│   │   │   └── runtime-config.js       # Generated runtime config
│   │   ├── src/
│   │   │   ├── components/
│   │   │   │   ├── ErrorBoundary.tsx
│   │   │   │   ├── Loading.tsx
│   │   │   │   └── Header.tsx
│   │   │   ├── pages/
│   │   │   │   ├── Home.tsx
│   │   │   │   └── NotFound.tsx
│   │   │   ├── plugins/
│   │   │   │   └── runtimePlugin.ts    # URL override plugin
│   │   │   ├── types/
│   │   │   │   └── remotes.d.ts
│   │   │   ├── App.tsx
│   │   │   ├── bootstrap.tsx
│   │   │   └── main.tsx
│   │   ├── module-federation.config.ts
│   │   ├── vite.config.ts
│   │   └── project.json
│   │
│   ├── product-mfe/                    # Product Micro Frontend
│   │   ├── src/
│   │   │   └── components/
│   │   │       ├── ProductList.tsx
│   │   │       └── ProductDetail.tsx
│   │   ├── module-federation.config.ts
│   │   ├── vite.config.ts
│   │   └── project.json
│   │
│   ├── cart-mfe/                       # Cart Micro Frontend
│   └── user-mfe/                       # User Micro Frontend
│
├── libs/
│   ├── shared/
│   │   ├── types/                      # Shared TypeScript types
│   │   │   └── src/index.ts
│   │   ├── constants/                  # App-wide constants
│   │   │   └── src/index.ts
│   │   ├── utils/                      # Helper functions
│   │   │   └── src/
│   │   │       ├── runtime.ts
│   │   │       ├── helpers.ts
│   │   │       ├── storage.ts
│   │   │       └── index.ts
│   │   ├── api/                        # API client & services
│   │   │   └── src/
│   │   │       ├── client.ts
│   │   │       ├── services.ts
│   │   │       └── index.ts
│   │   └── store/                      # State management
│   │       └── src/
│   │           ├── auth.store.ts
│   │           ├── cart.store.ts
│   │           ├── events.ts
│   │           └── index.ts
│   │
│   └── features/
│       └── routing/                    # Route configuration
│           └── src/
│               ├── config.ts
│               ├── loader.ts
│               └── index.ts
│
├── scripts/
│   └── generate-runtime-config.js      # Config generator script
│
├── .env.local                          # Development environment
├── .env.production                     # Production environment
├── nx.json                             # NX configuration
├── tsconfig.base.json                  # Base TypeScript config
├── package.json
└── README.md
```

---

## ⚙️ Configuration

### Environment Variables

**`.env.local`** (Development)
```bash
VITE_API_BASE_URL=http://localhost:4000
VITE_REMOTE_PRODUCT_URL=http://localhost:3001
VITE_REMOTE_CART_URL=http://localhost:3002
VITE_REMOTE_USER_URL=http://localhost:3003
```

**`.env.production`** (Production)
```bash
VITE_API_BASE_URL=https://api.yourcompany.com
VITE_REMOTE_PRODUCT_URL=https://product.yourcompany.com
VITE_REMOTE_CART_URL=https://cart.yourcompany.com
VITE_REMOTE_USER_URL=https://user.yourcompany.com
```

### Micro Frontend Configuration

Edit `libs/features/routing/src/config.ts` to add/modify routes:

```typescript
export const microFrontendConfig: MicroFrontendConfig[] = [
  {
    name: 'product',
    displayName: 'Products',
    routes: [
      {
        path: '/products',
        remote: 'product',
        module: './ProductList',
        meta: {
          title: 'Products',
          requiresAuth: false,
          showInNav: true,
          icon: '🛍️',
        },
      },
    ],
  },
];
```

---

## 🛠️ Development

### Adding a New Micro Frontend

1. **Create the app structure**:
```bash
mkdir -p apps/new-mfe/src/components
```

2. **Create `module-federation.config.ts`**:
```typescript
export default {
  name: 'newmfe',
  exposes: {
    './Component': './src/components/Component.tsx',
  },
  shared: { /* Match shell versions */ },
};
```

3. **Update environment files**:
```bash
# .env.local
VITE_REMOTE_NEWMFE_URL=http://localhost:3004
```

4. **Add to routing config**:
```typescript
// libs/features/routing/src/config.ts
{
  name: 'newmfe',
  routes: [{ path: '/new', remote: 'newmfe', module: './Component', ... }],
}
```

5. **Update shell's module-federation.config.ts**:
```typescript
remotes: {
  newmfe: { entry: 'http://localhost:3004/remoteEntry.js' },
}
```

### Development Commands

```bash
# Generate runtime config
npm run generate:config

# Start all apps
npm run dev

# Build all apps
npm run build

# Build for production
npm run build:prod

# Lint all apps
npm run lint

# Type check
npm run type-check
```

---

## 🚀 Deployment

### Build for Production

```bash
# 1. Update .env.production with production URLs

# 2. Generate production config
NODE_ENV=production npm run generate:config

# 3. Build all applications
npm run build:prod

# 4. Deploy each app separately
# - Shell: dist/apps/shell
# - Product: dist/apps/product-mfe
# - Cart: dist/apps/cart-mfe
# - User: dist/apps/user-mfe
```

### Deployment Checklist

- [ ] Update `.env.production` with production URLs
- [ ] Generate runtime config
- [ ] Build all applications
- [ ] Deploy each MFE to its respective URL
- [ ] Deploy shell last
- [ ] Verify all MFEs load correctly
- [ ] Test cross-MFE communication

---

## 📚 Best Practices

### ✅ DO

- **Use Runtime Plugin** - For URL overrides, not manual init()
- **Normal React Imports** - `import('product/ProductList')` works!
- **Centralize Versions** - Shell controls all shared dependency versions
- **Type Everything** - Use TypeScript declarations for remotes
- **Error Boundaries** - Wrap each MFE route
- **Event Bus** - For cross-MFE communication

### ❌ DON'T

- **Manual init()** - Not needed with this approach
- **Manual loadRemote()** - Use normal imports
- **Eager Loading** - Set `eager: false` in shared config
- **Version Mismatches** - Always match shell versions
- **Direct DOM Manipulation** - Use React patterns

---

## 🐛 Troubleshooting

### "createInstance first" Error

**Solution**: You're using the old approach. This architecture doesn't need manual `init()`.

### MFE Not Loading

**Checklist**:
1. Is the MFE server running?
2. Is `runtime-config.js` loaded before React?
3. Are the URLs in `.env.local` correct?
4. Check browser console for errors

### Module Not Found

**Checklist**:
1. Is the module exposed in `module-federation.config.ts`?
2. Is the TypeScript declaration in `remotes.d.ts`?
3. Is the path correct in route config?

### Version Conflicts

**Solution**: Ensure all MFEs use the same versions as shell in their `module-federation.config.ts`.

---

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the code examples
3. Check Module Federation docs

---

## 📄 License

MIT

---

**Built with ❤️ for enterprise micro frontend applications**
